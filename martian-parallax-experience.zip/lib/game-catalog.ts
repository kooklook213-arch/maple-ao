import { GameInfo } from './game-types';

export const GAME_CATALOG: GameInfo[] = [
  {
    id: 'drive-mad',
    title: 'Drive Mad (GN-Math)',
    category: 'Action',
    icon: '🚙',
    description: 'The iconic GN-Math physics driving game! Throttle, balance your monster truck over crazy ramps, avoid tipping over, and reach the finish line.',
    difficulty: 'Medium',
    highScoreKey: 'highscore-drivemad',
    tags: ['drive mad', 'gn-math', 'car', 'physics', 'stunt', 'racing', 'truck']
  },
  {
    id: 'slope',
    title: 'Slope 3D (GN-Math)',
    category: 'Speed',
    icon: '⚡',
    description: 'Speed roll down an endless neon 3D slope. Dodge lethal red obstacles, ride gravity boosts, and hit insane velocities.',
    difficulty: 'Hard',
    highScoreKey: 'highscore-slope',
    tags: ['slope', 'gn-math', 'speed', '3d', 'runner', 'reflex']
  },
  {
    id: 'geometry-dash',
    title: 'Geometry Dash (GN-Math)',
    category: 'Arcade',
    icon: '🟩',
    description: 'Jump, fly, and flip your neon cube through treacherous spike corridors to the rhythm. One wrong move resets the run!',
    difficulty: 'Hard',
    highScoreKey: 'highscore-geodash',
    tags: ['geometry dash', 'gn-math', 'rhythm', 'jump', 'arcade', 'reflex']
  },
  {
    id: 'cookie-clicker',
    title: 'Cookie Clicker (GN-Math)',
    category: 'Arcade',
    icon: '🍪',
    description: 'The legendary idle tycoon! Click the giant cookie, hire grandmas, construct cookie farms & quantum portals, and unlock heavenly upgrades.',
    difficulty: 'Easy',
    highScoreKey: 'highscore-cookie',
    tags: ['cookie clicker', 'gn-math', 'idle', 'tycoon', 'casual', 'clicker']
  },
  {
    id: 'tetris',
    title: 'Tetris Block Drop (GN-Math)',
    category: 'Puzzle',
    icon: '🧩',
    description: 'The classic Soviet falling blocks arcade! Rotate tetrominoes, drop ghost pieces, clear multiple lines, and rack up Tetris combos.',
    difficulty: 'Medium',
    highScoreKey: 'highscore-tetris',
    tags: ['tetris', 'gn-math', 'puzzle', 'retro', 'arcade', 'blocks']
  },
  {
    id: '2048',
    title: '2048 Puzzle',
    category: 'Puzzle',
    icon: '🔢',
    description: 'Join numbers and reach the 2048 tile with smooth sliding mechanics.',
    difficulty: 'Medium',
    highScoreKey: 'highscore-2048',
    tags: ['puzzle', 'math', 'strategy', 'casual']
  },
  {
    id: 'snake',
    title: 'Retro Snake Arcade',
    category: 'Arcade',
    icon: '🐍',
    description: 'Classic arcade snake with neon treats, speed progression, and smooth responsive grid.',
    difficulty: 'Easy',
    highScoreKey: 'highscore-snake',
    tags: ['arcade', 'retro', 'speed', 'classic']
  },
  {
    id: 'space',
    title: 'Space Defender',
    category: 'Action',
    icon: '🚀',
    description: 'Galactic retro arcade shooter. Blast alien swarms, dodge asteroid barrages, power-up shields.',
    difficulty: 'Hard',
    highScoreKey: 'highscore-space',
    tags: ['action', 'shooter', 'retro', 'space', 'arcade']
  },
  {
    id: 'blooket',
    title: 'Blooket Quiz Rush',
    category: 'Educational',
    icon: '⚡',
    description: 'Rapid-fire trivia and knowledge challenge inspired by Blooket classroom games with chest rewards!',
    difficulty: 'Medium',
    highScoreKey: 'highscore-blooket',
    tags: ['educational', 'blooket', 'trivia', 'quiz', 'classroom']
  },
  {
    id: 'mines',
    title: 'Minesweeper 99',
    category: 'Puzzle',
    icon: '💣',
    description: 'Classic logic deduction. Flag mines, uncover numbers, and clear the safe grid.',
    difficulty: 'Medium',
    highScoreKey: 'highscore-mines',
    tags: ['puzzle', 'logic', 'strategy', 'classic']
  },
  {
    id: 'flappy',
    title: 'Flappy Blook',
    category: 'Arcade',
    icon: '🐥',
    description: 'Tap or press space to flap between columns. Test your timing and reflexes.',
    difficulty: 'Hard',
    highScoreKey: 'highscore-flappy',
    tags: ['arcade', 'reflex', 'blook', 'flappy']
  }
];
