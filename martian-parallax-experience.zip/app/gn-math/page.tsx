import { GNMathPage } from "@/components/gnmath/GNMathPage"

export default function GNMathRoute() {
  return (
    <main className="min-h-screen bg-[#FAF9F5]">
      <GNMathPage />
    </main>
  )
}
