import { generateText } from 'ai'

const MAX_PROMPT_LENGTH = 4000
const MAX_HISTORY = 16

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      prompt?: string
      history?: Array<{ role: 'user' | 'assistant'; content: string }>
    }
    const prompt = body.prompt?.trim()
    if (!prompt) return Response.json({ error: 'Tell Nocturne what you want to automate.' }, { status: 400 })
    if (prompt.length > MAX_PROMPT_LENGTH) return Response.json({ error: 'Please keep messages under 4,000 characters.' }, { status: 413 })

    const history = (body.history ?? [])
      .filter((message) => (message.role === 'user' || message.role === 'assistant') && typeof message.content === 'string')
      .slice(-MAX_HISTORY)
      .map((message) => ({ role: message.role, content: message.content.slice(0, MAX_PROMPT_LENGTH) }))

    const result = await generateText({
      model: 'openai/o4-mini',
      system: `You are Nocturne, a concise but capable channel automation assistant. Help creators design schedules, content workflows, and practical next steps. Never claim an external automation was actually deployed; say what you prepared in this workspace. If a request includes a cadence, repeat it clearly. Use short paragraphs and bullets when useful.`,
      messages: [...history, { role: 'user', content: prompt }],
      maxOutputTokens: 700,
    })

    return Response.json({ text: result.text })
  } catch (error) {
    console.error('[v0] Nocturne AI request failed', error)
    return Response.json({ error: 'The AI assistant is unavailable right now. Try again in a moment.' }, { status: 500 })
  }
}
