"use client"

import Image from "next/image"
import Link from "next/link"
import { useState, useEffect, useRef } from "react"

export default function Page() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [gyroActive, setGyroActive] = useState(false)
  const [shouldAnimate, setShouldAnimate] = useState(false)
  const [animationComplete, setAnimationComplete] = useState(false)
  const frameRef = useRef<number | undefined>(undefined)
  const lastUpdateRef = useRef<number>(0)

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const x = (e.clientX - window.innerWidth / 2) / window.innerWidth
      const y = (e.clientY - window.innerHeight / 2) / window.innerHeight
      setMousePosition({ x, y })
    }

    const handleOrientation = (e: DeviceOrientationEvent) => {
      const now = Date.now()
      if (now - lastUpdateRef.current < 16) return
      lastUpdateRef.current = now

      if (frameRef.current) cancelAnimationFrame(frameRef.current)

      frameRef.current = requestAnimationFrame(() => {
        const isLandscape = window.innerWidth > window.innerHeight
        const value = isLandscape ? e.beta || 0 : e.gamma || 0
        const x = Math.max(-1, Math.min(1, value / 45))
        setMousePosition({ x, y: 0 })
      })
    }

    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent)
    const isTablet = /iPad|Android/i.test(navigator.userAgent) && window.innerWidth >= 768
    const isTouchDevice = isMobile || isTablet || "ontouchstart" in window || navigator.maxTouchPoints > 0

    if (isTouchDevice) {
      setGyroActive(true)
      setShouldAnimate(true)
    } else {
      window.addEventListener("mousemove", handleMouseMove)
      setShouldAnimate(true)
    }

    if (gyroActive) window.addEventListener("deviceorientation", handleOrientation)

    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("deviceorientation", handleOrientation)
      if (frameRef.current) cancelAnimationFrame(frameRef.current)
    }
  }, [gyroActive])

  useEffect(() => {
    const timer = setTimeout(() => setAnimationComplete(true), 4000)
    return () => clearTimeout(timer)
  }, [])

  return (
    <main className="relative isolate h-dvh w-full overflow-hidden bg-black">
      <nav aria-label="Account navigation" className="absolute right-6 top-6 z-40 flex items-center gap-2 sm:right-8 sm:top-8">
        <Link href="/login" className="rounded-full border border-white/40 bg-black/25 px-4 py-2 text-sm font-medium text-white backdrop-blur-md transition-colors hover:bg-white/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white">
          Log in
        </Link>
        <Link href="/login#signup" className="rounded-full bg-white px-4 py-2 text-sm font-medium text-black transition-colors hover:bg-white/85 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white">
          Sign up
        </Link>
      </nav>

      <div className={`absolute inset-0 ${shouldAnimate ? "zoom-layer-1" : ""}`} style={{ transform: `translate3d(${mousePosition.x * 30}px, ${mousePosition.y * 30}px, 0)`, willChange: "transform", width: "130%", height: "130%", left: "-15%", top: "-15%" }}>
        <Image src="/images/mars-1.png" alt="Mars planet from space" fill className="object-cover" priority />
      </div>
      <div className={`absolute z-5 ${shouldAnimate ? "zoom-layer-starship" : ""}`} style={{ transform: `translate3d(${mousePosition.x * 50}px, ${mousePosition.y * 50}px, 0) scale(0.75)`, willChange: "transform", width: "800px", height: "800px", left: "20px", top: "20px" }}>
        <Image src="/images/starship.png" alt="Space station" fill className="object-contain" />
      </div>
      <div className={`absolute inset-0 z-10 ${shouldAnimate ? "zoom-layer-2" : ""}`} style={{ transform: `translate3d(${mousePosition.x * 60}px, ${mousePosition.y * 60}px, 0)`, willChange: "transform", width: "130%", height: "130%", left: "-15%", top: "-15%" }}>
        <Image src="/images/mars-2.png" alt="Spacecraft interior window" fill className="object-cover" />
      </div>
      <div className={`absolute inset-0 flex items-center justify-center z-10 px-6 ${shouldAnimate ? "zoom-layer-text" : ""}`} style={{ transform: `translate3d(${mousePosition.x * 90}px, ${mousePosition.y * 90}px, 0)`, willChange: "transform", perspective: "1000px" }}>
        <h1 aria-label="Martian" className="flex text-[80px] sm:text-[120px] md:text-[160px] lg:text-[200px]">
          {"MARTIAN".split("").map((letter, index) => (
            <span key={index} className={`font-bold text-white ${shouldAnimate ? "letter-rotate" : ""}`} style={{ display: "inline-block", transformStyle: "preserve-3d" }}>{letter}</span>
          ))}
        </h1>
      </div>
      <div className={`absolute inset-0 z-20 ${shouldAnimate ? "zoom-layer-3" : ""}`} style={{ transform: `translate3d(${mousePosition.x * 120}px, ${mousePosition.y * 120}px, 0)`, willChange: "transform", width: "110%", height: "110%", left: "-5%", top: "calc(-5% + 150px)" }}>
        <Image src="/images/mars-3.png" alt="Astronaut in orange spacesuit" fill className="object-cover" />
      </div>

      <div className="absolute inset-x-0 bottom-6 z-40 flex flex-col items-center gap-2 px-4 text-center sm:bottom-9">
        <Link
          href="/workspace"
          className="inline-flex min-h-11 items-center gap-3 rounded-full border border-white/70 bg-white px-6 py-3 text-sm font-semibold text-black shadow-[0_12px_36px_rgba(0,0,0,0.24)] transition duration-200 hover:-translate-y-0.5 hover:bg-white/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-black"
        >
          Continue as guest <span aria-hidden="true">→</span>
        </Link>
        <p className="text-xs font-medium text-white drop-shadow-md">No account needed</p>
      </div>

      <style jsx>{`
        .zoom-layer-1 { animation: zoomOut1 8s cubic-bezier(0.4, 0, 0.2, 1) forwards; }
        .zoom-layer-starship { animation: zoomOutStarship 8s cubic-bezier(0.4, 0, 0.2, 1) forwards; }
        .zoom-layer-2 { animation: zoomOut2 8s cubic-bezier(0.4, 0, 0.2, 1) forwards; }
        .zoom-layer-3 { animation: zoomOut3 8s cubic-bezier(0.4, 0, 0.2, 1) forwards; }
        .zoom-layer-text { animation: zoomOutText 8s cubic-bezier(0.4, 0, 0.2, 1) forwards; }
        @keyframes zoomOut1 { 0% { scale: 1.3; } 100% { scale: 1; } }
        @keyframes zoomOutStarship { 0% { scale: 1.5; } 100% { scale: 0.75; } }
        @keyframes zoomOut2 { 0% { scale: 2.5; filter: blur(20px); } 50% { filter: blur(10px); } 100% { scale: 1; filter: blur(0px); } }
        @keyframes zoomOut3 { 0% { scale: 8; filter: blur(40px); opacity: 0; } 30% { filter: blur(25px); opacity: 0.3; } 70% { filter: blur(10px); opacity: 0.7; } 100% { scale: 1; filter: blur(0px); opacity: 1; } }
        @keyframes zoomOutText { 0% { scale: 3.5; opacity: 0; } 40% { opacity: 0.3; } 70% { opacity: 0.7; } 100% { scale: 1; opacity: 1; } }
        .letter-rotate { animation: rotateText 8s cubic-bezier(0.4, 0, 0.2, 1) forwards; }
        @keyframes rotateText { 0% { transform: rotateY(90deg); filter: blur(30px); opacity: 0; } 40% { filter: blur(15px); opacity: 0.5; } 70% { filter: blur(5px); opacity: 0.8; } 100% { transform: rotateY(0deg); filter: blur(0px); opacity: 1; } }
      `}</style>
    </main>
  )
}
