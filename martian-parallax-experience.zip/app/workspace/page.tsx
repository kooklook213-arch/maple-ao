'use client';

import {
  ArrowUp,
  Check,
  ChevronRight,
  CircleHelp,
  Gamepad2,
  Menu,
  MoreHorizontal,
  Plus,
  Sparkles,
  X,
} from 'lucide-react';
import { FormEvent, KeyboardEvent, useEffect, useMemo, useRef, useState } from 'react';
import { GameArena } from '@/components/nocturne/games/GameArena';
import { GAME_CATALOG } from '@/data/nocturne-games';
import { GameModeId } from '@/types/nocturne';

type Schedule = {
  id: string;
  title: string;
  cadence: string;
  active: boolean;
};

type Message = {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  schedule?: Schedule;
};

const starterSchedules: Schedule[] = [
  { id: 'weekly-rober', title: 'Weekly Mark Rober Video', cadence: 'Tuesdays · 9:00 AM', active: true },
  { id: 'daily-shorts', title: 'Daily Science Shorts', cadence: 'Daily · 4:30 PM', active: true },
];

const suggestions = [
  'Schedule a Mark Rober style video every Tuesday',
  'Create a science Short every weekday at 4 PM',
  'Plan a build-challenge video every 3 days',
];

function loadSchedules() {
  try {
    const saved = localStorage.getItem('nocturne-schedules');
    return saved ? (JSON.parse(saved) as Schedule[]) : starterSchedules;
  } catch {
    return starterSchedules;
  }
}

function parseCadence(input: string) {
  const lower = input.toLowerCase();
  const everyDays = lower.match(/every\s+(\d+)\s+days?/);
  if (everyDays) return `Every ${everyDays[1]} days`;
  const weekday = lower.match(/every\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)/);
  if (weekday) return `Every ${weekday[1][0].toUpperCase()}${weekday[1].slice(1)}`;
  if (/weekdays?/.test(lower)) return 'Weekdays';
  if (/daily|every day/.test(lower)) return 'Daily';
  if (/weekly|every week/.test(lower)) return 'Weekly';
  return 'Recurring';
}

function parseTitle(input: string) {
  const lower = input.toLowerCase();
  if (/mark\s+rob(er|ert)/.test(lower)) return 'Mark Rober Video';
  if (/science/.test(lower) && /short/.test(lower)) return 'Science Shorts';
  if (/build/.test(lower) && /challenge/.test(lower)) return 'Build Challenge Video';
  const cleaned = input
    .replace(/^(please\s+)?(make|create|schedule|plan|set up)\s+(me\s+)?/i, '')
    .replace(/\s+(every|each|daily|weekly|on)\b.*$/i, '')
    .trim();
  return cleaned ? cleaned.replace(/\b\w/g, (letter) => letter.toUpperCase()).slice(0, 42) : 'New Channel Automation';
}

function isScheduleRequest(input: string) {
  return /\b(schedule|every|daily|weekly|weekdays|each\s+(day|week)|set up|automation)\b/i.test(input);
}

export default function App() {
  const [view, setView] = useState<'chat' | 'games'>('chat');
  const [schedules, setSchedules] = useState<Schedule[]>(loadSchedules);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [online, setOnline] = useState(true);
  const [activeGame, setActiveGame] = useState<GameModeId | null>(null);
  const [scoreNote, setScoreNote] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const feedRef = useRef<HTMLDivElement>(null);

  const activeCount = useMemo(() => schedules.filter((schedule) => schedule.active).length, [schedules]);

  useEffect(() => {
    localStorage.setItem('nocturne-schedules', JSON.stringify(schedules));
  }, [schedules]);

  useEffect(() => {
    if (!textareaRef.current) return;
    textareaRef.current.style.height = 'auto';
    textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 164)}px`;
  }, [input]);

  useEffect(() => {
    feedRef.current?.scrollTo({ top: feedRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, thinking]);

  const openComposer = () => {
    setView('chat');
    setSidebarOpen(false);
    setInput('Create a new channel automation that ');
    window.setTimeout(() => textareaRef.current?.focus(), 50);
  };

  const sendMessage = async (value = input) => {
    const prompt = value.trim();
    if (!prompt || thinking) return;

    setView('chat');
    setMessages((current) => [...current, { id: `user-${Date.now()}`, role: 'user', text: prompt }]);
    setInput('');
    setThinking(true);
    try {
      const response = await fetch('/api/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, history: messages.map((message) => ({ role: message.role, content: message.text })) }),
      });
      const data = await response.json();
      const schedule = isScheduleRequest(prompt) ? { id: `schedule-${Date.now()}`, title: parseTitle(prompt), cadence: parseCadence(prompt), active: true } : undefined;
      if (schedule) setSchedules((current) => [schedule, ...current]);
      setMessages((current) => [...current, { id: `assistant-${Date.now()}`, role: 'assistant', text: data.text ?? data.error ?? 'I could not complete that request.', schedule }]);
    } catch {
      setMessages((current) => [...current, { id: `assistant-${Date.now()}`, role: 'assistant', text: 'I could not reach the secure AI service. Please try again.' }]);
    } finally {
      setThinking(false);
    }
  };

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    sendMessage();
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      sendMessage();
    }
  };

  const chooseGame = (gameId: GameModeId) => {
    setView('games');
    setActiveGame(gameId);
    setSidebarOpen(false);
  };

  const reportScore = (gameId: string, score: number) => {
    const game = GAME_CATALOG.find((item) => item.id === gameId);
    setScoreNote(`${game?.title || 'Game'} score saved: ${score.toLocaleString()}`);
    window.setTimeout(() => setScoreNote(''), 2800);
  };

  return (
    <div className="app-shell">
      {sidebarOpen && <button className="sidebar-scrim" onClick={() => setSidebarOpen(false)} aria-label="Close sidebar" />}

      <aside className={`sidebar ${sidebarOpen ? 'is-open' : ''}`}>
        <div className="sidebar-topline">
          <button className="brand" onClick={() => { setView('chat'); setSidebarOpen(false); }} aria-label="Nocturne home">
            <span className="brand-mark">N</span>
            <span>Nocturne</span>
          </button>
          <button className="mobile-close" onClick={() => setSidebarOpen(false)} aria-label="Close menu"><X size={18} /></button>
        </div>

        <button className="new-schedule" onClick={openComposer}>
          <Plus size={16} strokeWidth={1.8} />
          <span>New automation schedule</span>
        </button>

        <nav className="sidebar-scroll" aria-label="Workspace navigation">
          <section className="sidebar-section">
            <div className="section-label">
              <span>Active schedules</span>
              <span>{activeCount}</span>
            </div>
            <div className="schedule-list">
              {schedules.map((schedule) => (
                <button
                  className="schedule-row"
                  key={schedule.id}
                  onClick={() => setSchedules((current) => current.map((item) => item.id === schedule.id ? { ...item, active: !item.active } : item))}
                  title={schedule.active ? 'Pause schedule' : 'Resume schedule'}
                >
                  <span className={`status-dot ${schedule.active ? 'is-active' : ''}`} />
                  <span className="schedule-copy">
                    <strong>{schedule.title}</strong>
                    <small>{schedule.active ? schedule.cadence : 'Paused'}</small>
                  </span>
                  <MoreHorizontal size={15} />
                </button>
              ))}
            </div>
          </section>

          <section className="sidebar-section play-section">
            <div className="section-label"><span>Take a break</span></div>
            <button className={`nav-row ${view === 'games' ? 'is-selected' : ''}`} onClick={() => { setView('games'); setActiveGame(null); setSidebarOpen(false); }}>
              <Gamepad2 size={16} />
              <span>Playroom</span>
              <span className="count-chip">11</span>
            </button>
            {GAME_CATALOG.slice(0, 3).map((game) => (
              <button className="mini-game-row" key={game.id} onClick={() => chooseGame(game.id)}>
                <span>{game.icon}</span>
                <span>{game.title.replace(' (GN-Math)', '')}</span>
              </button>
            ))}
          </section>
        </nav>

        <div className="profile-block">
          <button className="profile-main">
            <span className="avatar">KL</span>
            <span className="profile-copy"><strong>Kook Look</strong><small>Creator workspace</small></span>
            <ChevronRight size={15} />
          </button>
          <button className="availability" onClick={() => setOnline((value) => !value)} aria-pressed={online}>
            <span><span className={`presence ${online ? 'is-online' : ''}`} />{online ? 'Automations online' : 'Automations paused'}</span>
            <span className={`switch ${online ? 'is-on' : ''}`}><span /></span>
          </button>
        </div>
      </aside>

      <main className="workspace">
        <header className="workspace-header">
          <button className="menu-button" onClick={() => setSidebarOpen(true)} aria-label="Open menu"><Menu size={19} /></button>
          <div>
            <p>{view === 'chat' ? 'Automation workspace' : 'Creator playroom'}</p>
            <h1>{view === 'chat' ? 'Channel assistant' : activeGame ? GAME_CATALOG.find((game) => game.id === activeGame)?.title.replace(' (GN-Math)', '') : 'Take a break'}</h1>
          </div>
          <div className="header-tools">
            <span className="sync-state"><span />Saved locally</span>
            <button className="icon-button" aria-label="Help"><CircleHelp size={18} /></button>
          </div>
        </header>

        {view === 'chat' ? (
          <div className="chat-view">
            <div className="feed" ref={feedRef}>
              {messages.length === 0 ? (
                <section className="welcome">
                  <div className="assistant-emblem" aria-hidden="true"><span>✦</span></div>
                  <p className="welcome-kicker">MuleRun automation assistant</p>
                  <h2>How can I help you automate your channel today?</h2>
                  <p className="welcome-note">Describe the video and rhythm. I’ll turn it into a schedule you can track.</p>
                  <div className="suggestion-grid">
                    {suggestions.map((suggestion) => (
                      <button key={suggestion} onClick={() => sendMessage(suggestion)}>
                        <span>{suggestion}</span>
                        <ArrowUp size={16} />
                      </button>
                    ))}
                  </div>
                </section>
              ) : (
                <div className="message-thread">
                  {messages.map((message) => (
                    <article className={`message ${message.role}`} key={message.id}>
                      {message.role === 'assistant' && <div className="agent-icon">✦</div>}
                      <div className="message-body">
                        <p>{message.text}</p>
                        {message.schedule && (
                          <div className="schedule-confirmation">
                            <div className="confirmation-head"><Check size={14} /><span>Schedule created</span></div>
                            <dl>
                              <div><dt>Name</dt><dd>{message.schedule.title}</dd></div>
                              <div><dt>Cadence</dt><dd>{message.schedule.cadence}</dd></div>
                              <div><dt>Runner</dt><dd>MuleRun Cloud</dd></div>
                              <div><dt>Status</dt><dd><span className="live-dot" />Active</dd></div>
                            </dl>
                          </div>
                        )}
                      </div>
                    </article>
                  ))}
                  {thinking && (
                    <article className="message assistant">
                      <div className="agent-icon">✦</div>
                      <div className="thinking"><span /><span /><span /></div>
                    </article>
                  )}
                </div>
              )}
            </div>

            <div className="composer-area">
              <form className="composer" onSubmit={handleSubmit}>
                <textarea
                  ref={textareaRef}
                  rows={1}
                  value={input}
                  onChange={(event) => setInput(event.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Describe an automation..."
                  aria-label="Automation instructions"
                />
                <div className="composer-footer">
                  <span>MuleRun</span>
                  <button type="submit" disabled={!input.trim() || thinking} aria-label="Send message"><ArrowUp size={18} /></button>
                </div>
              </form>
              <p className="composer-hint">Press Enter to send · Shift + Enter for a new line</p>
            </div>
          </div>
        ) : (
          <div className="games-view">
            {activeGame ? (
              <GameArena activeGameId={activeGame} onSelectGame={setActiveGame} onClose={() => setActiveGame(null)} onScoreSubmit={reportScore} />
            ) : (
              <section className="game-library">
                <div className="library-intro">
                  <span className="eyebrow">A small reset</span>
                  <h2>Play for five minutes.</h2>
                  <p>Your automations keep running while you clear your head. Pick up exactly where you left off.</p>
                </div>
                <div className="game-grid">
                  {GAME_CATALOG.map((game, index) => (
                    <button className="game-card" key={game.id} onClick={() => setActiveGame(game.id)}>
                      <span className="game-card-number">{String(index + 1).padStart(2, '0')}</span>
                      <span className="game-card-icon">{game.thumbnail ? <img src={game.thumbnail} alt="" loading="lazy" /> : game.icon}</span>
                      <span className="game-card-copy">
                        <strong>{game.title.replace(' (GN-Math)', '')}</strong>
                        <small>{game.description}</small>
                      </span>
                      <span className="game-card-meta"><span>{game.category}</span><span>{game.difficulty}</span></span>
                    </button>
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </main>

      {scoreNote && <div className="score-toast"><Check size={15} />{scoreNote}</div>}
    </div>
  );
}
