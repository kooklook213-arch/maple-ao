"use client"

import { Suspense, useEffect, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { supabase } from "@/lib/supabase/client"

function CallbackContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [message, setMessage] = useState("Completing sign-in…")

  useEffect(() => {
    let active = true
    async function completeSignIn() {
      const errorDescription = searchParams.get("error_description")
      if (errorDescription) { setMessage(errorDescription); return }
      const code = searchParams.get("code")
      const result = code ? await supabase.auth.exchangeCodeForSession(code) : await supabase.auth.getSession()
      if (!active) return
      if (result.error) { setMessage(result.error.message); return }
      if (window.opener && !window.opener.closed) {
        window.opener.postMessage({ type: "elbert-auth-complete" }, window.location.origin)
        window.close()
        return
      }
      router.replace("/workspace")
      router.refresh()
    }
    completeSignIn()
    return () => { active = false }
  }, [router, searchParams])

  return <p role="status">{message}</p>
}

export default function AuthCallbackPage() {
  return <main className="flex min-h-dvh items-center justify-center bg-white px-6 text-sm text-neutral-600"><Suspense fallback={<p role="status">Completing sign-in…</p>}><CallbackContent /></Suspense></main>
}
