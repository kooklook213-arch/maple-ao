export type NavigationPage = 
  | 'home' 
  | 'projects' 
  | 'clients' 
  | 'automations' 
  | 'calendar' 
  | 'customize' 
  | 'settings' 
  | 'game-portal' 
  | 'bookmarks'
  | 'gemini-studio'
  | 'gn-math';


export type GameModeId = 
  | '2048' 
  | 'snake' 
  | 'space' 
  | 'blooket' 
  | 'mines' 
  | 'flappy' 
  | 'racer' 
  | 'breakout'
  | 'drive-mad'
  | 'slope'
  | 'geometry-dash'
  | 'cookie-clicker'
  | 'tetris';

export interface GameInfo {
  id: GameModeId;
  title: string;
  category: 'Arcade' | 'Puzzle' | 'Action' | 'Educational' | 'Retro' | 'Speed';
  icon: string;
  thumbnail?: string;
  description: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  highScoreKey: string;
  tags: string[];
}

export interface TaskItem {
  id: string;
  title: string;
  time?: string;
  status: 'pending' | 'in_progress' | 'completed';
  client?: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  createdAt: string;
}

export interface BookmarkItem {
  id: string;
  title: string;
  url: string;
  icon?: string;
  category: 'games' | 'search' | 'tools' | 'social';
  isGame?: boolean;
  gameId?: string;
  pinned: boolean;
}

export interface ChatMessage {
  id: string;
  user: string;
  text: string;
  time: string;
  avatar?: string;
  badge?: string;
}

export interface GameScore {
  gameId: string;
  gameTitle: string;
  user: string;
  score: number;
  date: string;
}

export interface UserProfile {
  name: string;
  username: string;
  email: string;
  plan: 'Free' | 'Pro' | 'Enterprise';
  avatarChar: string;
  theme: 'paper' | 'nocturne' | 'aurora' | 'emerald' | 'amber';
  searchEngine: 'duckduckgo' | 'google' | 'brave';
  compactView: boolean;
  notificationsEnabled: boolean;
  soundEffects: boolean;
}

export interface AppState {
  tasks: TaskItem[];
  bookmarks: BookmarkItem[];
  chatMessages: ChatMessage[];
  gameScores: GameScore[];
  profile: UserProfile;
}

export interface ProjectCard {
  id: string;
  title: string;
  client: string;
  status: 'backlog' | 'in_progress' | 'review' | 'done';
  dueDate: string;
  assignee: string;
  tasksCount: number;
  completedTasks: number;
  tag: string;
}

export interface ClientItem {
  id: string;
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
  retainer: string;
  status: 'active' | 'pending' | 'review';
  hoursLogged: number;
  hoursLimit: number;
  activeTasks: number;
  recentInvoice: {
    number: string;
    amount: string;
    status: 'paid' | 'overdue' | 'sent';
    dueDate: string;
  };
}

export interface AutomationRule {
  id: string;
  name: string;
  trigger: string;
  action: string;
  enabled: boolean;
  runsCount: number;
  lastRun: string;
  proOnly: boolean;
}
