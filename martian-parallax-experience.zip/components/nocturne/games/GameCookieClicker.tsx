import React, { useState, useEffect, useRef } from 'react';
import { playSound } from '@/utils/nocturne-sound';
import { Sparkles, Cookie, Trophy, TrendingUp } from 'lucide-react';

interface Props {
  onScoreSubmit?: (score: number) => void;
  onExit?: () => void;
}

interface Building {
  id: string;
  name: string;
  cost: number;
  cps: number;
  count: number;
  icon: string;
}

interface ClickParticle {
  id: number;
  x: number;
  y: number;
  text: string;
}

export const GameCookieClicker: React.FC<Props> = ({ onScoreSubmit }) => {
  const [cookies, setCookies] = useState<number>(() => {
    return parseInt(localStorage.getItem('cookie-count') || '0', 10);
  });
  const [totalBaked, setTotalBaked] = useState<number>(() => {
    return parseInt(localStorage.getItem('cookie-total') || '0', 10);
  });
  const [clickPower, setClickPower] = useState<number>(1);
  const [isCookiePressed, setIsCookiePressed] = useState<boolean>(false);
  const [particles, setParticles] = useState<ClickParticle[]>([]);
  const [goldenCookie, setGoldenCookie] = useState<{ x: number; y: number } | null>(null);

  const [buildings, setBuildings] = useState<Building[]>([
    { id: 'cursor', name: 'Auto-Clicker', cost: 15, cps: 0.5, count: 0, icon: '👆' },
    { id: 'grandma', name: 'Grandma Baker', cost: 100, cps: 4, count: 0, icon: '👵' },
    { id: 'farm', name: 'Cookie Farm', cost: 1100, cps: 16, count: 0, icon: '🌾' },
    { id: 'mine', name: 'Chocolate Mine', cost: 12000, cps: 64, count: 0, icon: '⛏️' },
    { id: 'factory', name: 'Quantum Bakery', cost: 130000, cps: 260, count: 0, icon: '🏭' },
    { id: 'lab', name: 'Alchemy Lab', cost: 1400000, cps: 1100, count: 0, icon: '⚗️' }
  ]);

  const totalCps = buildings.reduce((acc, b) => acc + b.count * b.cps, 0);

  // CPS Tick interval
  useEffect(() => {
    const interval = setInterval(() => {
      if (totalCps > 0) {
        setCookies(c => {
          const next = c + totalCps / 10;
          return next;
        });
        setTotalBaked(t => {
          const next = t + totalCps / 10;
          localStorage.setItem('cookie-total', Math.floor(next).toString());
          return next;
        });
      }
    }, 100);

    return () => clearInterval(interval);
  }, [totalCps]);

  // Golden Cookie Spawner
  useEffect(() => {
    const goldenTimer = setInterval(() => {
      if (Math.random() < 0.25 && !goldenCookie) {
        setGoldenCookie({
          x: Math.floor(Math.random() * 200) + 20,
          y: Math.floor(Math.random() * 180) + 20
        });
      }
    }, 15000);

    return () => clearInterval(goldenTimer);
  }, [goldenCookie]);

  // Click Cookie
  const handleCookieClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    playSound('score');
    setIsCookiePressed(true);
    setTimeout(() => setIsCookiePressed(false), 120);

    const gained = clickPower;
    setCookies(c => c + gained);
    setTotalBaked(t => {
      const next = t + gained;
      localStorage.setItem('cookie-total', Math.floor(next).toString());
      if (onScoreSubmit && Math.floor(next) % 100 === 0) {
        onScoreSubmit(Math.floor(next));
      }
      return next;
    });

    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const pid = Date.now() + Math.random();
    setParticles(prev => [...prev, { id: pid, x, y, text: `+${gained}` }]);
    setTimeout(() => {
      setParticles(prev => prev.filter(p => p.id !== pid));
    }, 800);
  };

  const clickGoldenCookie = () => {
    playSound('success');
    const bonus = Math.max(50, Math.floor(totalCps * 15) + 100);
    setCookies(c => c + bonus);
    setTotalBaked(t => t + bonus);
    setGoldenCookie(null);
  };

  const buyBuilding = (bId: string) => {
    const target = buildings.find(b => b.id === bId);
    if (!target || cookies < target.cost) return;

    playSound('task');
    setCookies(c => c - target.cost);
    setBuildings(prev =>
      prev.map(b =>
        b.id === bId
          ? {
              ...b,
              count: b.count + 1,
              cost: Math.floor(b.cost * 1.15)
            }
          : b
      )
    );
  };

  return (
    <div className="flex flex-col items-center max-w-lg mx-auto p-3 select-none w-full">
      {/* Top Counters */}
      <div className="flex items-center justify-between w-full mb-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-amber-400 tracking-tight flex items-center gap-1.5">
            <span>🍪</span> Cookie Clicker (GN-Math)
          </h2>
          <p className="text-xs text-stone-400">CPS: {totalCps.toFixed(1)} cookies/sec</p>
        </div>

        <div className="bg-stone-900 border border-amber-500/40 px-4 py-1.5 rounded-xl text-center">
          <span className="text-[10px] uppercase font-bold text-amber-300 block">Total Baked</span>
          <span className="text-base font-black text-amber-400">{Math.floor(totalBaked).toLocaleString()}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full">
        {/* Cookie Click Stage */}
        <div className="bg-[#0b0c16] border border-amber-500/30 rounded-2xl p-6 flex flex-col items-center justify-center relative overflow-hidden shadow-xl min-h-[260px]">
          {/* Golden Cookie */}
          {goldenCookie && (
            <button
              onClick={clickGoldenCookie}
              style={{ left: `${goldenCookie.x}px`, top: `${goldenCookie.y}px` }}
              className="absolute text-3xl animate-bounce z-20 hover:scale-125 transition-transform"
              title="GOLDEN COOKIE! Click for Frenzy!"
            >
              🌟
            </button>
          )}

          <div className="text-center mb-3">
            <span className="text-3xl font-black text-white">{Math.floor(cookies).toLocaleString()}</span>
            <span className="text-xs text-amber-300 block">cookies</span>
          </div>

          <button
            onClick={handleCookieClick}
            className={`relative text-7xl sm:text-8xl transition-transform active:scale-90 hover:scale-105 cursor-pointer filter drop-shadow-[0_0_20px_rgba(245,158,11,0.35)] ${
              isCookiePressed ? 'scale-90 rotate-6' : ''
            }`}
          >
            🍪
          </button>

          {/* Floating click particles */}
          {particles.map(p => (
            <span
              key={p.id}
              style={{ left: `${p.x}px`, top: `${p.y}px` }}
              className="absolute text-amber-300 font-black text-sm pointer-events-none animate-float-up"
            >
              {p.text}
            </span>
          ))}

          <span className="text-[11px] text-stone-400 mt-4">Tap to bake +{clickPower}</span>
        </div>

        {/* Buildings Upgrades Store */}
        <div className="bg-[#0d0e1d] border border-stone-700/80 rounded-2xl p-3 flex flex-col gap-2 max-h-[300px] overflow-y-auto">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-300 px-1">
            Bakery Upgrades
          </span>

          {buildings.map(b => {
            const canAfford = cookies >= b.cost;
            return (
              <button
                key={b.id}
                disabled={!canAfford}
                onClick={() => buyBuilding(b.id)}
                className={`flex items-center justify-between p-2.5 rounded-xl border text-left transition-all ${
                  canAfford
                    ? 'bg-stone-850 hover:bg-stone-800 border-amber-500/40 text-white cursor-pointer active:scale-98'
                    : 'bg-stone-900 border-stone-800 text-stone-500 opacity-60 cursor-not-allowed'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-xl">{b.icon}</span>
                  <div>
                    <div className="text-xs font-bold truncate">{b.name}</div>
                    <div className="text-[10px] text-amber-400 font-mono">+{b.cps} cps</div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-xs font-extrabold text-amber-300">🍪 {b.cost.toLocaleString()}</div>
                  <div className="text-[10px] text-stone-400 font-bold">Qty: {b.count}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
