import React, { useState, useEffect, useRef, useCallback } from 'react';
import { playSound } from '@/utils/nocturne-sound';

interface Props {
  onScoreSubmit?: (score: number) => void;
  onExit?: () => void;
}

interface Obstacle {
  x: number;
  type: 'spike' | 'block' | 'pad';
}

export const GameGeometryDash: React.FC<Props> = ({ onScoreSubmit }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [progress, setProgress] = useState<number>(0);
  const [attempt, setAttempt] = useState<number>(1);
  const [bestProgress, setBestProgress] = useState<number>(() => {
    return parseInt(localStorage.getItem('highscore-geodash') || '0', 10);
  });
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [won, setWon] = useState<boolean>(false);

  // Cube state in ref
  const cubeRef = useRef({
    x: 60,
    y: 190,
    vy: 0,
    size: 24,
    angle: 0,
    isGrounded: true,
    jumpForce: -7.5,
    gravity: 0.44
  });

  const animFrameRef = useRef<number>(0);
  const courseLengthRef = useRef<number>(2400);
  const distanceRef = useRef<number>(0);
  const obstaclesRef = useRef<Obstacle[]>([]);

  const buildCourse = useCallback(() => {
    const list: Obstacle[] = [];
    const len = courseLengthRef.current;
    for (let x = 320; x < len; x += 140 + Math.random() * 80) {
      const r = Math.random();
      if (r < 0.6) {
        list.push({ x, type: 'spike' });
      } else if (r < 0.85) {
        list.push({ x, type: 'spike' });
        list.push({ x: x + 24, type: 'spike' }); // Double spike!
      } else {
        list.push({ x, type: 'block' });
      }
    }
    obstaclesRef.current = list;
  }, []);

  const jump = useCallback(() => {
    const cube = cubeRef.current;
    if (gameOver) {
      resetGame();
      return;
    }
    if (cube.isGrounded) {
      cube.vy = cube.jumpForce;
      cube.isGrounded = false;
      playSound('jump');
    }
  }, [gameOver]);

  const resetGame = useCallback(() => {
    cubeRef.current = {
      x: 60,
      y: 190,
      vy: 0,
      size: 24,
      angle: 0,
      isGrounded: true,
      jumpForce: -7.5,
      gravity: 0.44
    };
    distanceRef.current = 0;
    setProgress(0);
    setGameOver(false);
    setWon(false);
    setAttempt(a => a + 1);
  }, []);

  useEffect(() => {
    buildCourse();
  }, [buildCourse]);

  // Controls
  useEffect(() => {
    const onDown = (e: KeyboardEvent) => {
      if (['Space', 'ArrowUp', 'KeyW'].includes(e.code)) {
        e.preventDefault();
        jump();
      }
    };
    window.addEventListener('keydown', onDown);
    return () => window.removeEventListener('keydown', onDown);
  }, [jump]);

  // Game Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const groundY = 220;

    const loop = () => {
      const cube = cubeRef.current;

      if (!gameOver && !won) {
        distanceRef.current += 3.4;
        const curDist = distanceRef.current;
        const pct = Math.min(100, Math.round((curDist / courseLengthRef.current) * 100));
        setProgress(pct);

        if (pct > bestProgress) {
          setBestProgress(pct);
          localStorage.setItem('highscore-geodash', pct.toString());
        }

        if (pct >= 100) {
          setWon(true);
          playSound('success');
          if (onScoreSubmit) onScoreSubmit(100);
        }

        // Cube physics
        cube.vy += cube.gravity;
        cube.y += cube.vy;

        if (!cube.isGrounded) {
          cube.angle += 0.12; // Flip in air
        } else {
          // Snap angle
          cube.angle = Math.round(cube.angle / (Math.PI / 2)) * (Math.PI / 2);
        }

        // Ground hit
        if (cube.y + cube.size >= groundY) {
          cube.y = groundY - cube.size;
          cube.vy = 0;
          cube.isGrounded = true;
        }

        // Check Obstacle Collisions
        for (const ob of obstaclesRef.current) {
          const screenX = ob.x - curDist;
          if (screenX > -40 && screenX < 120) {
            if (ob.type === 'spike') {
              // Spike triangle collision
              const spikeBase = groundY;
              const spikeH = 22;
              const spikeW = 20;

              const inX = cube.x + cube.size > screenX && cube.x < screenX + spikeW;
              const inY = cube.y + cube.size > spikeBase - spikeH;

              if (inX && inY) {
                setGameOver(true);
                playSound('hit');
                playSound('gameover');
                break;
              }
            } else if (ob.type === 'block') {
              const bH = 26;
              const bW = 26;
              const inX = cube.x + cube.size > screenX && cube.x < screenX + bW;
              const inFront = cube.y + cube.size > groundY - bH + 4;

              if (inX && inFront) {
                setGameOver(true);
                playSound('hit');
                playSound('gameover');
                break;
              }
            }
          }
        }
      }

      // Render
      ctx.fillStyle = '#060714';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Neon grid background
      ctx.strokeStyle = '#1a1936';
      ctx.lineWidth = 1;
      const offset = (distanceRef.current * 0.5) % 40;
      for (let x = -offset; x < canvas.width; x += 40) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }

      // Ground
      ctx.fillStyle = '#0f0e26';
      ctx.fillRect(0, groundY, canvas.width, canvas.height - groundY);
      ctx.strokeStyle = '#06b6d4';
      ctx.lineWidth = 3;
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#06b6d4';
      ctx.beginPath();
      ctx.moveTo(0, groundY);
      ctx.lineTo(canvas.width, groundY);
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Obstacles
      obstaclesRef.current.forEach(ob => {
        const screenX = ob.x - distanceRef.current;
        if (screenX > -30 && screenX < canvas.width + 30) {
          if (ob.type === 'spike') {
            ctx.fillStyle = '#ec4899';
            ctx.shadowBlur = 12;
            ctx.shadowColor = '#f43f5e';
            ctx.beginPath();
            ctx.moveTo(screenX + 10, groundY - 22);
            ctx.lineTo(screenX, groundY);
            ctx.lineTo(screenX + 20, groundY);
            ctx.closePath();
            ctx.fill();
            ctx.shadowBlur = 0;
          } else if (ob.type === 'block') {
            ctx.fillStyle = '#3b82f6';
            ctx.strokeStyle = '#60a5fa';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.roundRect(screenX, groundY - 26, 26, 26, 3);
            ctx.fill();
            ctx.stroke();
          }
        }
      });

      // Neon Cube
      ctx.save();
      ctx.translate(cube.x + cube.size / 2, cube.y + cube.size / 2);
      ctx.rotate(cube.angle);

      ctx.shadowBlur = 15;
      ctx.shadowColor = '#a855f7';
      ctx.fillStyle = '#c084fc';
      ctx.fillRect(-cube.size / 2, -cube.size / 2, cube.size, cube.size);

      // Cube Eye / Inner Face
      ctx.fillStyle = '#05060d';
      ctx.fillRect(-cube.size / 4, -cube.size / 4, cube.size / 2, cube.size / 2);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-2, -4, 4, 8);

      ctx.restore();

      animFrameRef.current = requestAnimationFrame(loop);
    };

    animFrameRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [gameOver, won, bestProgress, onScoreSubmit]);

  return (
    <div className="flex flex-col items-center justify-center max-w-sm mx-auto p-3 select-none">
      <div className="flex items-center justify-between w-full mb-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-purple-400 tracking-tight flex items-center gap-1.5">
            <span>🟩</span> Geometry Dash (GN-Math)
          </h2>
          <p className="text-xs text-stone-400">Attempt #{attempt} · Tap / Space to jump spikes</p>
        </div>

        <div className="flex gap-2">
          <div className="bg-stone-900 border border-stone-700 px-3 py-1.5 rounded-xl text-center min-w-16">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Progress</span>
            <span className="text-sm font-black text-white">{progress}%</span>
          </div>
          <div className="bg-stone-900 border border-stone-700 px-3 py-1.5 rounded-xl text-center min-w-16">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Best</span>
            <span className="text-sm font-black text-purple-400">{bestProgress}%</span>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-stone-800 rounded-full h-2 mb-2 overflow-hidden border border-stone-700">
        <div
          className="bg-purple-500 h-full transition-all duration-75 shadow-[0_0_8px_#c084fc]"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div
        onClick={jump}
        className="relative rounded-2xl overflow-hidden border border-purple-500/40 shadow-[0_0_25px_rgba(168,85,247,0.2)] bg-black cursor-pointer"
      >
        <canvas ref={canvasRef} width={340} height={260} className="w-72 h-56 sm:w-80 sm:h-64 block" />

        {gameOver && (
          <div className="absolute inset-0 bg-stone-950/85 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center z-10 animate-fade-in">
            <span className="text-4xl mb-1">💥</span>
            <h3 className="text-xl font-bold text-red-400 mb-1">Crashed at {progress}%</h3>
            <p className="text-xs text-stone-300 mb-4">Attempt #{attempt}</p>
            <button
              onClick={e => {
                e.stopPropagation();
                resetGame();
              }}
              className="bg-purple-600 hover:bg-purple-500 text-white font-bold px-6 py-2 rounded-xl text-xs shadow-lg transition-transform active:scale-95"
            >
              Retry Level
            </button>
          </div>
        )}

        {won && (
          <div className="absolute inset-0 bg-stone-950/85 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center z-10 animate-fade-in">
            <span className="text-4xl mb-1">🏆</span>
            <h3 className="text-xl font-bold text-emerald-400 mb-1">100% COMPLETE!</h3>
            <p className="text-xs text-stone-300 mb-4">Geometry Dash Level Conquered!</p>
            <button
              onClick={e => {
                e.stopPropagation();
                resetGame();
              }}
              className="bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-bold px-6 py-2 rounded-xl text-xs shadow-lg transition-transform active:scale-95"
            >
              Play Again
            </button>
          </div>
        )}
      </div>

      {/* Jump Button for Mobile */}
      <div className="mt-3 w-full">
        <button
          onClick={jump}
          className="w-full py-3.5 bg-purple-600 hover:bg-purple-500 active:scale-98 text-white font-black rounded-xl text-sm shadow-[0_0_20px_rgba(168,85,247,0.4)] transition-transform"
        >
          TAP TO JUMP 🚀
        </button>
      </div>
    </div>
  );
};
