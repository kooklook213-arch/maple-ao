import React, { useState, useEffect, useRef, useCallback } from 'react';
import { playSound } from '@/utils/nocturne-sound';

interface Props {
  onScoreSubmit?: (score: number) => void;
  onExit?: () => void;
}

interface TerrainPoint {
  x: number;
  y: number;
}

export const GameDriveMad: React.FC<Props> = ({ onScoreSubmit }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [level, setLevel] = useState<number>(1);
  const [score, setScore] = useState<number>(0);
  const [bestScore, setBestScore] = useState<number>(() => {
    return parseInt(localStorage.getItem('highscore-drivemad') || '0', 10);
  });
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [levelWon, setLevelWon] = useState<boolean>(false);

  // Car Physics State in Ref for 60fps loop
  const carRef = useRef({
    x: 80,
    y: 220,
    vx: 0,
    vy: 0,
    angle: 0,
    vAngle: 0,
    wheelR: 16,
    wheelBase: 48,
    isGrounded: false,
    crashed: false
  });

  const keysRef = useRef<{ [key: string]: boolean }>({});
  const animFrameRef = useRef<number>(0);

  // Generate terrain for level
  const terrainRef = useRef<TerrainPoint[]>([]);
  const finishXRef = useRef<number>(1600);

  const buildTerrain = useCallback((lvl: number) => {
    const points: TerrainPoint[] = [];
    points.push({ x: 0, y: 280 });
    points.push({ x: 160, y: 280 });

    let curX = 160;
    let curY = 280;

    // Build segments
    const segments = 12 + lvl * 2;
    for (let i = 0; i < segments; i++) {
      const segType = Math.floor((i + lvl) % 4);
      if (segType === 0) {
        // Flat speedway
        curX += 90;
        points.push({ x: curX, y: curY });
      } else if (segType === 1) {
        // Ramp up
        curX += 80;
        curY -= 45;
        points.push({ x: curX, y: curY });
        curX += 60;
        curY += 45;
        points.push({ x: curX, y: curY });
      } else if (segType === 2) {
        // Steeper hill
        curX += 70;
        curY -= 65;
        points.push({ x: curX, y: curY });
        curX += 80;
        curY += 65;
        points.push({ x: curX, y: curY });
      } else {
        // Bump
        curX += 50;
        curY -= 25;
        points.push({ x: curX, y: curY });
        curX += 50;
        curY += 25;
        points.push({ x: curX, y: curY });
      }
    }

    curX += 140;
    points.push({ x: curX, y: 280 });
    finishXRef.current = curX - 40;
    terrainRef.current = points;
  }, []);

  const resetTruck = useCallback(() => {
    carRef.current = {
      x: 80,
      y: 220,
      vx: 0,
      vy: 0,
      angle: 0,
      vAngle: 0,
      wheelR: 16,
      wheelBase: 48,
      isGrounded: false,
      crashed: false
    };
    setGameOver(false);
    setLevelWon(false);
  }, []);

  const resetGame = useCallback(() => {
    buildTerrain(level);
    resetTruck();
  }, [level, buildTerrain, resetTruck]);

  useEffect(() => {
    resetGame();
  }, [resetGame]);

  // Keyboard controls
  useEffect(() => {
    const onDown = (e: KeyboardEvent) => {
      keysRef.current[e.code] = true;
      if (['ArrowRight', 'ArrowLeft', 'ArrowUp', 'ArrowDown', 'KeyW', 'KeyS', 'KeyD', 'KeyA'].includes(e.code)) {
        e.preventDefault();
      }
      if (e.code === 'KeyR') {
        resetTruck();
      }
    };
    const onUp = (e: KeyboardEvent) => {
      keysRef.current[e.code] = false;
    };
    window.addEventListener('keydown', onDown);
    window.addEventListener('keyup', onUp);
    return () => {
      window.removeEventListener('keydown', onDown);
      window.removeEventListener('keyup', onUp);
    };
  }, [resetTruck]);

  // Main Physics & Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const loop = () => {
      const car = carRef.current;
      const terrain = terrainRef.current;

      if (!car.crashed && !levelWon) {
        // Acceleration / Reverse
        const isRight = keysRef.current['ArrowRight'] || keysRef.current['KeyD'] || keysRef.current['ArrowUp'] || keysRef.current['KeyW'];
        const isLeft = keysRef.current['ArrowLeft'] || keysRef.current['KeyA'] || keysRef.current['ArrowDown'] || keysRef.current['KeyS'];

        if (isRight) {
          car.vx += 0.32;
          car.vAngle += 0.005; // Wheelie torque
        }
        if (isLeft) {
          car.vx -= 0.22;
          car.vAngle -= 0.006; // Nose down
        }

        // Air drag & friction
        car.vx *= 0.985;
        car.vy += 0.36; // Gravity
        car.vAngle *= 0.96;

        // Position integration
        car.x += car.vx;
        car.y += car.vy;
        car.angle += car.vAngle;

        // Find terrain height at wheels
        const rearX = car.x - Math.cos(car.angle) * (car.wheelBase / 2);
        const frontX = car.x + Math.cos(car.angle) * (car.wheelBase / 2);

        const getTerrainY = (x: number): number => {
          for (let i = 0; i < terrain.length - 1; i++) {
            if (x >= terrain[i].x && x <= terrain[i + 1].x) {
              const t = (x - terrain[i].x) / (terrain[i + 1].x - terrain[i].x);
              return terrain[i].y + t * (terrain[i + 1].y - terrain[i].y);
            }
          }
          return 380;
        };

        const rearTy = getTerrainY(rearX);
        const frontTy = getTerrainY(frontX);
        const groundAvgY = (rearTy + frontTy) / 2;

        const rearContact = car.y + car.wheelR >= rearTy;
        const frontContact = car.y + car.wheelR >= frontTy;

        if (rearContact || frontContact) {
          car.isGrounded = true;
          // Align car angle with slope
          const slopeAngle = Math.atan2(frontTy - rearTy, frontX - rearX);
          const angleDiff = slopeAngle - car.angle;
          car.vAngle += angleDiff * 0.15;

          // Prevent sinking
          if (car.y + car.wheelR > groundAvgY) {
            car.y = groundAvgY - car.wheelR;
            car.vy = 0;
          }
        } else {
          car.isGrounded = false;
        }

        // Crash detection: Cab hit ground (car upside down)
        const normalizedAngle = ((car.angle % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
        const isUpsideDown = normalizedAngle > Math.PI * 0.55 && normalizedAngle < Math.PI * 1.45;
        if (isUpsideDown && car.y + 10 >= groundAvgY) {
          car.crashed = true;
          setGameOver(true);
          playSound('hit');
          playSound('gameover');
        }

        // Checkpoint / Finish line detection
        if (car.x >= finishXRef.current) {
          setLevelWon(true);
          playSound('success');
          setScore(s => {
            const ns = s + 500 * level;
            if (ns > bestScore) {
              setBestScore(ns);
              localStorage.setItem('highscore-drivemad', ns.toString());
            }
            if (onScoreSubmit) onScoreSubmit(ns);
            return ns;
          });
        }
      }

      // Render Scene
      ctx.fillStyle = '#05060d';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Camera follows truck
      ctx.save();
      const cameraX = Math.max(0, car.x - 120);
      ctx.translate(-cameraX, 0);

      // Background mountain silhouettes
      ctx.fillStyle = '#100f24';
      ctx.beginPath();
      ctx.moveTo(-100, 360);
      for (let m = 0; m < 20; m++) {
        ctx.lineTo(m * 120, 200 + ((m * 37) % 70));
      }
      ctx.lineTo(3000, 360);
      ctx.fill();

      // Draw Terrain Blocks
      ctx.fillStyle = '#1c1a38';
      ctx.strokeStyle = '#4e4887';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(-100, 400);
      for (let p of terrain) {
        ctx.lineTo(p.x, p.y);
      }
      ctx.lineTo(finishXRef.current + 300, 400);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Grass / Top neon contour
      ctx.strokeStyle = '#9085e9';
      ctx.lineWidth = 4;
      ctx.beginPath();
      for (let i = 0; i < terrain.length; i++) {
        if (i === 0) ctx.moveTo(terrain[i].x, terrain[i].y);
        else ctx.lineTo(terrain[i].x, terrain[i].y);
      }
      ctx.stroke();

      // Checkered Finish Banner
      const fx = finishXRef.current;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(fx, 170, 6, 110);
      ctx.fillStyle = '#10b981';
      ctx.fillRect(fx + 6, 170, 34, 24);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 10px monospace';
      ctx.fillText('FINISH', fx + 8, 186);

      // Draw Monster Truck
      ctx.save();
      ctx.translate(car.x, car.y);
      ctx.rotate(car.angle);

      // Cab / Chassis
      ctx.fillStyle = car.crashed ? '#ef4444' : '#3b82f6';
      ctx.shadowBlur = 10;
      ctx.shadowColor = car.crashed ? '#ef4444' : '#60a5fa';

      // Truck Body
      ctx.beginPath();
      ctx.roundRect(-24, -18, 48, 16, 4);
      ctx.fill();

      // Truck Cabin
      ctx.fillStyle = '#1e3a8a';
      ctx.beginPath();
      ctx.roundRect(-10, -32, 28, 14, 3);
      ctx.fill();

      // Window
      ctx.fillStyle = '#93c5fd';
      ctx.fillRect(-2, -30, 16, 10);

      // Truck Bed / Exhaust pipe
      ctx.fillStyle = '#9ca3af';
      ctx.fillRect(-20, -26, 4, 10);
      if (keysRef.current['ArrowRight'] || keysRef.current['KeyD']) {
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(-22, -28 - Math.random() * 4, 3, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.shadowBlur = 0;

      // Suspension Bars
      ctx.strokeStyle = '#6b7280';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(-18, 0);
      ctx.lineTo(-20, 12);
      ctx.moveTo(18, 0);
      ctx.lineTo(20, 12);
      ctx.stroke();

      // Wheels
      const drawWheel = (wx: number, wy: number) => {
        ctx.save();
        ctx.translate(wx, wy);
        ctx.rotate(car.x * 0.08); // Rotate with movement
        ctx.fillStyle = '#111827';
        ctx.beginPath();
        ctx.arc(0, 0, car.wheelR, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#374151';
        ctx.lineWidth = 3;
        ctx.stroke();

        // Rim
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(0, 0, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      };

      drawWheel(-car.wheelBase / 2, 12);
      drawWheel(car.wheelBase / 2, 12);

      ctx.restore();
      ctx.restore();

      animFrameRef.current = requestAnimationFrame(loop);
    };

    animFrameRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [levelWon, bestScore, level, onScoreSubmit]);

  const nextLevel = () => {
    setLevel(l => l + 1);
    resetGame();
  };

  return (
    <div className="flex flex-col items-center justify-center max-w-lg mx-auto p-3 select-none">
      {/* Top Banner */}
      <div className="flex items-center justify-between w-full mb-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-blue-400 tracking-tight flex items-center gap-1.5">
            <span>🚙</span> Drive Mad (GN-Math)
          </h2>
          <p className="text-xs text-stone-400">Balance your truck over insane ramps &amp; gaps</p>
        </div>

        <div className="flex gap-2">
          <div className="bg-stone-900 border border-stone-700 px-3 py-1.5 rounded-xl text-center min-w-16">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Level</span>
            <span className="text-sm font-black text-amber-400">{level}</span>
          </div>
          <div className="bg-stone-900 border border-stone-700 px-3 py-1.5 rounded-xl text-center min-w-16">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Best</span>
            <span className="text-sm font-black text-emerald-400">{bestScore}</span>
          </div>
        </div>
      </div>

      {/* Canvas Viewport */}
      <div className="relative rounded-2xl overflow-hidden border border-blue-500/40 shadow-[0_0_25px_rgba(59,130,246,0.2)] bg-black">
        <canvas ref={canvasRef} width={420} height={280} className="w-80 h-56 sm:w-96 sm:h-64 block" />

        {/* Crashed Screen */}
        {gameOver && (
          <div className="absolute inset-0 bg-stone-950/85 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center z-10 animate-fade-in">
            <span className="text-4xl mb-1">💥</span>
            <h3 className="text-xl font-bold text-red-400 mb-1">Wasted! Cab Crashed</h3>
            <p className="text-xs text-stone-300 mb-4">Keep your wheels on the ground and balance</p>
            <button
              onClick={resetTruck}
              className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-6 py-2 rounded-xl text-xs shadow-lg transition-transform active:scale-95"
            >
              Retry Level {level} (R)
            </button>
          </div>
        )}

        {/* Level Complete Screen */}
        {levelWon && (
          <div className="absolute inset-0 bg-stone-950/85 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center z-10 animate-fade-in">
            <span className="text-4xl mb-1">🏆</span>
            <h3 className="text-xl font-bold text-emerald-400 mb-1">Level {level} Cleared!</h3>
            <p className="text-xs text-stone-300 mb-4">+500 Points awarded</p>
            <button
              onClick={nextLevel}
              className="bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-bold px-6 py-2 rounded-xl text-xs shadow-lg transition-transform active:scale-95"
            >
              Next Level →
            </button>
          </div>
        )}
      </div>

      {/* Mobile Touch Controls */}
      <div className="mt-3 flex items-center justify-between w-full px-2">
        <div className="flex gap-2">
          <button
            onTouchStart={() => { keysRef.current['ArrowLeft'] = true; }}
            onTouchEnd={() => { keysRef.current['ArrowLeft'] = false; }}
            onMouseDown={() => { keysRef.current['ArrowLeft'] = true; }}
            onMouseUp={() => { keysRef.current['ArrowLeft'] = false; }}
            className="w-16 h-12 bg-stone-800 active:bg-blue-600 rounded-xl text-white font-bold flex flex-col items-center justify-center border border-stone-700 shadow"
          >
            <span className="text-base">◀◀</span>
            <span className="text-[9px] text-stone-400">BRAKE</span>
          </button>
        </div>

        <button
          onClick={resetTruck}
          className="px-3 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-xl text-xs border border-stone-700"
        >
          Reset (R)
        </button>

        <div className="flex gap-2">
          <button
            onTouchStart={() => { keysRef.current['ArrowRight'] = true; }}
            onTouchEnd={() => { keysRef.current['ArrowRight'] = false; }}
            onMouseDown={() => { keysRef.current['ArrowRight'] = true; }}
            onMouseUp={() => { keysRef.current['ArrowRight'] = false; }}
            className="w-20 h-12 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded-xl text-white font-bold flex flex-col items-center justify-center shadow-[0_0_15px_rgba(59,130,246,0.4)]"
          >
            <span className="text-base">GAS ▶▶</span>
            <span className="text-[9px] text-blue-200">ACCEL</span>
          </button>
        </div>
      </div>
    </div>
  );
};
