import React, { useState, useEffect, useRef, useCallback } from 'react';
import { playSound } from '@/utils/nocturne-sound';

interface Props {
  onScoreSubmit?: (score: number) => void;
  onExit?: () => void;
}

const GRID_SIZE = 20;

export const GameSnake: React.FC<Props> = ({ onScoreSubmit }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [snake, setSnake] = useState<{ x: number; y: number }[]>([
    { x: 10, y: 10 },
    { x: 10, y: 11 },
    { x: 10, y: 12 },
  ]);
  const [food, setFood] = useState<{ x: number; y: number }>({ x: 5, y: 5 });
  const [direction, setDirection] = useState<'UP' | 'DOWN' | 'LEFT' | 'RIGHT'>('UP');
  const dirRef = useRef<'UP' | 'DOWN' | 'LEFT' | 'RIGHT'>('UP');
  const [score, setScore] = useState<number>(0);
  const [bestScore, setBestScore] = useState<number>(() => {
    return parseInt(localStorage.getItem('highscore-snake') || '0', 10);
  });
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(110);

  const generateFood = useCallback((currentSnake: { x: number; y: number }[]) => {
    while (true) {
      const rx = Math.floor(Math.random() * GRID_SIZE);
      const ry = Math.floor(Math.random() * GRID_SIZE);
      if (!currentSnake.some(seg => seg.x === rx && seg.y === ry)) {
        return { x: rx, y: ry };
      }
    }
  }, []);

  const resetGame = useCallback(() => {
    const initialSnake = [
      { x: 10, y: 10 },
      { x: 10, y: 11 },
      { x: 10, y: 12 },
    ];
    setSnake(initialSnake);
    setDirection('UP');
    dirRef.current = 'UP';
    setFood(generateFood(initialSnake));
    setScore(0);
    setSpeed(110);
    setGameOver(false);
    setIsPaused(false);
  }, [generateFood]);

  const changeDirection = useCallback((newDir: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT') => {
    const current = dirRef.current;
    if (newDir === 'UP' && current !== 'DOWN') { dirRef.current = 'UP'; setDirection('UP'); }
    else if (newDir === 'DOWN' && current !== 'UP') { dirRef.current = 'DOWN'; setDirection('DOWN'); }
    else if (newDir === 'LEFT' && current !== 'RIGHT') { dirRef.current = 'LEFT'; setDirection('LEFT'); }
    else if (newDir === 'RIGHT' && current !== 'LEFT') { dirRef.current = 'RIGHT'; setDirection('RIGHT'); }
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['ArrowUp', 'KeyW'].includes(e.code)) {
        e.preventDefault();
        changeDirection('UP');
      } else if (['ArrowDown', 'KeyS'].includes(e.code)) {
        e.preventDefault();
        changeDirection('DOWN');
      } else if (['ArrowLeft', 'KeyA'].includes(e.code)) {
        e.preventDefault();
        changeDirection('LEFT');
      } else if (['ArrowRight', 'KeyD'].includes(e.code)) {
        e.preventDefault();
        changeDirection('RIGHT');
      } else if (e.code === 'Space') {
        e.preventDefault();
        setIsPaused(p => !p);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [changeDirection]);

  // Game Loop
  useEffect(() => {
    if (gameOver || isPaused) return;

    const interval = setInterval(() => {
      setSnake(prevSnake => {
        const head = { ...prevSnake[0] };
        const curDir = dirRef.current;

        if (curDir === 'UP') head.y -= 1;
        if (curDir === 'DOWN') head.y += 1;
        if (curDir === 'LEFT') head.x -= 1;
        if (curDir === 'RIGHT') head.x += 1;

        // Wall collisions
        if (head.x < 0 || head.x >= GRID_SIZE || head.y < 0 || head.y >= GRID_SIZE) {
          setGameOver(true);
          playSound('hit');
          playSound('gameover');
          if (onScoreSubmit) onScoreSubmit(score);
          return prevSnake;
        }

        // Self collisions
        if (prevSnake.some(seg => seg.x === head.x && seg.y === head.y)) {
          setGameOver(true);
          playSound('hit');
          playSound('gameover');
          if (onScoreSubmit) onScoreSubmit(score);
          return prevSnake;
        }

        const newSnake = [head, ...prevSnake];

        // Eat food
        if (head.x === food.x && head.y === food.y) {
          playSound('score');
          const newScore = score + 10;
          setScore(newScore);
          if (newScore > bestScore) {
            setBestScore(newScore);
            localStorage.setItem('highscore-snake', newScore.toString());
          }
          setFood(generateFood(newSnake));
          if (speed > 55) setSpeed(s => s - 2);
        } else {
          newSnake.pop();
        }

        return newSnake;
      });
    }, speed);

    return () => clearInterval(interval);
  }, [gameOver, isPaused, food, score, bestScore, speed, generateFood, onScoreSubmit]);

  // Render to canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const cellSize = canvas.width / GRID_SIZE;

    // Dark grid background
    ctx.fillStyle = '#0b0c16';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Subtle grid lines
    ctx.strokeStyle = '#1a1d2e';
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= GRID_SIZE; i++) {
      ctx.beginPath();
      ctx.moveTo(i * cellSize, 0);
      ctx.lineTo(i * cellSize, canvas.height);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i * cellSize);
      ctx.lineTo(canvas.width, i * cellSize);
      ctx.stroke();
    }

    // Draw food with pulsing neon glow
    ctx.shadowBlur = 12;
    ctx.shadowColor = '#10b981';
    ctx.fillStyle = '#34d399';
    ctx.beginPath();
    ctx.arc(
      food.x * cellSize + cellSize / 2,
      food.y * cellSize + cellSize / 2,
      cellSize / 2.5,
      0,
      Math.PI * 2
    );
    ctx.fill();

    // Draw snake with gradient body
    snake.forEach((seg, idx) => {
      const isHead = idx === 0;
      ctx.shadowBlur = isHead ? 15 : 6;
      ctx.shadowColor = '#818cf8';
      ctx.fillStyle = isHead ? '#c084fc' : '#a855f7';

      const pad = 1.5;
      ctx.beginPath();
      ctx.roundRect(
        seg.x * cellSize + pad,
        seg.y * cellSize + pad,
        cellSize - pad * 2,
        cellSize - pad * 2,
        isHead ? 6 : 4
      );
      ctx.fill();

      // Snake eyes
      if (isHead) {
        ctx.fillStyle = '#ffffff';
        ctx.shadowBlur = 0;
        const eyeOffset = cellSize / 3.5;
        const eyeSize = 2;
        let ex1 = seg.x * cellSize + cellSize / 2 - eyeOffset;
        let ey1 = seg.y * cellSize + cellSize / 2 - eyeOffset;
        let ex2 = seg.x * cellSize + cellSize / 2 + eyeOffset;
        let ey2 = seg.y * cellSize + cellSize / 2 - eyeOffset;

        if (direction === 'DOWN') {
          ey1 += eyeOffset * 2;
          ey2 += eyeOffset * 2;
        } else if (direction === 'LEFT') {
          ex1 = seg.x * cellSize + cellSize / 2 - eyeOffset;
          ex2 = ex1;
          ey1 = seg.y * cellSize + cellSize / 2 - eyeOffset;
          ey2 = seg.y * cellSize + cellSize / 2 + eyeOffset;
        } else if (direction === 'RIGHT') {
          ex1 = seg.x * cellSize + cellSize / 2 + eyeOffset;
          ex2 = ex1;
          ey1 = seg.y * cellSize + cellSize / 2 - eyeOffset;
          ey2 = seg.y * cellSize + cellSize / 2 + eyeOffset;
        }

        ctx.beginPath();
        ctx.arc(ex1, ey1, eyeSize, 0, Math.PI * 2);
        ctx.arc(ex2, ey2, eyeSize, 0, Math.PI * 2);
        ctx.fill();
      }
    });

    ctx.shadowBlur = 0;
  }, [snake, food, direction]);

  return (
    <div className="flex flex-col items-center justify-center max-w-sm mx-auto p-4 select-none">
      <div className="flex items-center justify-between w-full mb-3">
        <div>
          <h2 className="text-2xl font-black text-purple-400 tracking-tight flex items-center gap-1.5">
            <span>🐍</span> Snake Arcade
          </h2>
          <p className="text-xs text-stone-400">Eat treats, survive &amp; grow</p>
        </div>
        <div className="flex gap-2">
          <div className="bg-stone-800/80 px-3 py-1.5 rounded-lg text-center border border-stone-700/60 min-w-16">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Score</span>
            <span className="text-sm font-bold text-white">{score}</span>
          </div>
          <div className="bg-stone-800/80 px-3 py-1.5 rounded-lg text-center border border-stone-700/60 min-w-16">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Best</span>
            <span className="text-sm font-bold text-emerald-400">{bestScore}</span>
          </div>
        </div>
      </div>

      <div className="relative rounded-2xl overflow-hidden border border-purple-500/30 shadow-[0_0_25px_rgba(168,85,247,0.15)]">
        <canvas ref={canvasRef} width={320} height={320} className="w-72 h-72 sm:w-80 sm:h-80 block" />

        {gameOver && (
          <div className="absolute inset-0 bg-stone-950/85 backdrop-blur-sm flex flex-col items-center justify-center p-4 text-center z-10 animate-fade-in">
            <h3 className="text-2xl font-bold text-red-400 mb-1">Game Over!</h3>
            <p className="text-xs text-stone-300 mb-4">You scored {score} points</p>
            <button
              onClick={resetGame}
              className="bg-purple-600 hover:bg-purple-700 text-white font-bold px-5 py-2 rounded-xl text-sm transition-transform active:scale-95 shadow-lg"
            >
              Play Again
            </button>
          </div>
        )}

        {isPaused && !gameOver && (
          <div className="absolute inset-0 bg-stone-950/70 backdrop-blur-sm flex flex-col items-center justify-center p-4 text-center z-10">
            <h3 className="text-xl font-bold text-amber-300 mb-2">Paused</h3>
            <button
              onClick={() => setIsPaused(false)}
              className="bg-stone-800 hover:bg-stone-700 text-white px-4 py-1.5 rounded-lg text-xs"
            >
              Resume
            </button>
          </div>
        )}
      </div>

      {/* Touch D-Pad for Mobile */}
      <div className="mt-4 flex flex-col items-center gap-1.5 w-full">
        <button
          onClick={() => changeDirection('UP')}
          className="w-12 h-10 bg-stone-800 hover:bg-stone-700 active:bg-purple-600 rounded-lg text-white font-bold flex items-center justify-center border border-stone-700 text-sm shadow"
          aria-label="Up"
        >
          ▲
        </button>
        <div className="flex gap-4">
          <button
            onClick={() => changeDirection('LEFT')}
            className="w-12 h-10 bg-stone-800 hover:bg-stone-700 active:bg-purple-600 rounded-lg text-white font-bold flex items-center justify-center border border-stone-700 text-sm shadow"
            aria-label="Left"
          >
            ◀
          </button>
          <button
            onClick={() => changeDirection('DOWN')}
            className="w-12 h-10 bg-stone-800 hover:bg-stone-700 active:bg-purple-600 rounded-lg text-white font-bold flex items-center justify-center border border-stone-700 text-sm shadow"
            aria-label="Down"
          >
            ▼
          </button>
          <button
            onClick={() => changeDirection('RIGHT')}
            className="w-12 h-10 bg-stone-800 hover:bg-stone-700 active:bg-purple-600 rounded-lg text-white font-bold flex items-center justify-center border border-stone-700 text-sm shadow"
            aria-label="Right"
          >
            ▶
          </button>
        </div>
      </div>

      <div className="flex gap-3 mt-3">
        <button
          onClick={() => setIsPaused(p => !p)}
          className="text-xs px-3 py-1.5 rounded-lg bg-stone-800/80 hover:bg-stone-700 text-stone-300 border border-stone-700 transition-colors"
        >
          {isPaused ? 'Resume' : 'Pause'}
        </button>
        <button
          onClick={resetGame}
          className="text-xs px-3 py-1.5 rounded-lg bg-stone-800/80 hover:bg-stone-700 text-stone-300 border border-stone-700 transition-colors"
        >
          Restart
        </button>
      </div>
    </div>
  );
};
