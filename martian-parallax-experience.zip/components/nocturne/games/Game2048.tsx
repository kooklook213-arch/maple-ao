import React, { useState, useEffect, useCallback } from 'react';
import { playSound } from '@/utils/nocturne-sound';

interface Props {
  onScoreSubmit?: (score: number) => void;
  onExit?: () => void;
}

type Board = number[][];

export const Game2048: React.FC<Props> = ({ onScoreSubmit }) => {
  const [board, setBoard] = useState<Board>(createEmptyBoard());
  const [score, setScore] = useState<number>(0);
  const [bestScore, setBestScore] = useState<number>(() => {
    return parseInt(localStorage.getItem('highscore-2048') || '0', 10);
  });
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [hasWon, setHasWon] = useState<boolean>(false);

  function createEmptyBoard(): Board {
    return [
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ];
  }

  const addRandomTile = useCallback((currentBoard: Board): Board => {
    const emptyCells: { r: number; c: number }[] = [];
    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 4; c++) {
        if (currentBoard[r][c] === 0) emptyCells.push({ r, c });
      }
    }
    if (emptyCells.length === 0) return currentBoard;
    const { r, c } = emptyCells[Math.floor(Math.random() * emptyCells.length)];
    const newBoard = currentBoard.map(row => [...row]);
    newBoard[r][c] = Math.random() < 0.9 ? 2 : 4;
    return newBoard;
  }, []);

  const resetGame = useCallback(() => {
    let b = createEmptyBoard();
    b = addRandomTile(b);
    b = addRandomTile(b);
    setBoard(b);
    setScore(0);
    setGameOver(false);
    setHasWon(false);
  }, [addRandomTile]);

  useEffect(() => {
    resetGame();
  }, [resetGame]);

  const slideRow = (row: number[]): { newRow: number[]; gained: number } => {
    const filtered = row.filter(val => val !== 0);
    let gained = 0;
    const result: number[] = [];

    for (let i = 0; i < filtered.length; i++) {
      if (filtered[i] === filtered[i + 1]) {
        const combined = filtered[i] * 2;
        result.push(combined);
        gained += combined;
        i++;
      } else {
        result.push(filtered[i]);
      }
    }

    while (result.length < 4) {
      result.push(0);
    }

    return { newRow: result, gained };
  };

  const move = useCallback(
    (dir: 'left' | 'right' | 'up' | 'down') => {
      if (gameOver) return;

      let current = board.map(row => [...row]);
      let totalGained = 0;
      let changed = false;

      if (dir === 'left') {
        for (let r = 0; r < 4; r++) {
          const { newRow, gained } = slideRow(current[r]);
          totalGained += gained;
          if (newRow.some((val, idx) => val !== current[r][idx])) changed = true;
          current[r] = newRow;
        }
      } else if (dir === 'right') {
        for (let r = 0; r < 4; r++) {
          const reversed = [...current[r]].reverse();
          const { newRow, gained } = slideRow(reversed);
          newRow.reverse();
          totalGained += gained;
          if (newRow.some((val, idx) => val !== current[r][idx])) changed = true;
          current[r] = newRow;
        }
      } else if (dir === 'up') {
        for (let c = 0; c < 4; c++) {
          const col = [current[0][c], current[1][c], current[2][c], current[3][c]];
          const { newRow, gained } = slideRow(col);
          totalGained += gained;
          for (let r = 0; r < 4; r++) {
            if (current[r][c] !== newRow[r]) changed = true;
            current[r][c] = newRow[r];
          }
        }
      } else if (dir === 'down') {
        for (let c = 0; c < 4; c++) {
          const col = [current[3][c], current[2][c], current[1][c], current[0][c]];
          const { newRow, gained } = slideRow(col);
          newRow.reverse();
          totalGained += gained;
          for (let r = 0; r < 4; r++) {
            if (current[r][c] !== newRow[r]) changed = true;
            current[r][c] = newRow[r];
          }
        }
      }

      if (changed) {
        playSound('click');
        const nextBoard = addRandomTile(current);
        const newScore = score + totalGained;
        setBoard(nextBoard);
        setScore(newScore);

        if (newScore > bestScore) {
          setBestScore(newScore);
          localStorage.setItem('highscore-2048', newScore.toString());
        }

        // Check 2048 tile
        let won = false;
        let canMove = false;
        for (let r = 0; r < 4; r++) {
          for (let c = 0; c < 4; c++) {
            if (nextBoard[r][c] === 2048) won = true;
            if (nextBoard[r][c] === 0) canMove = true;
            if (r < 3 && nextBoard[r][c] === nextBoard[r + 1][c]) canMove = true;
            if (c < 3 && nextBoard[r][c] === nextBoard[r][c + 1]) canMove = true;
          }
        }

        if (won && !hasWon) {
          setHasWon(true);
          playSound('success');
        }

        if (!canMove) {
          setGameOver(true);
          playSound('gameover');
          if (onScoreSubmit) onScoreSubmit(newScore);
        }
      }
    },
    [board, gameOver, score, bestScore, hasWon, addRandomTile, onScoreSubmit]
  );

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['ArrowUp', 'KeyW'].includes(e.code)) {
        e.preventDefault();
        move('up');
      } else if (['ArrowDown', 'KeyS'].includes(e.code)) {
        e.preventDefault();
        move('down');
      } else if (['ArrowLeft', 'KeyA'].includes(e.code)) {
        e.preventDefault();
        move('left');
      } else if (['ArrowRight', 'KeyD'].includes(e.code)) {
        e.preventDefault();
        move('right');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [move]);

  const getTileColor = (val: number): string => {
    switch (val) {
      case 2: return 'bg-[#EEE4DA] text-[#776E65]';
      case 4: return 'bg-[#EDE0C8] text-[#776E65]';
      case 8: return 'bg-[#F2B179] text-white';
      case 16: return 'bg-[#F59563] text-white';
      case 32: return 'bg-[#F67C5F] text-white';
      case 64: return 'bg-[#F65E3B] text-white';
      case 128: return 'bg-[#EDCF72] text-white shadow-[0_0_10px_#EDCF72]';
      case 256: return 'bg-[#EDCC61] text-white shadow-[0_0_15px_#EDCC61]';
      case 512: return 'bg-[#EDC850] text-white shadow-[0_0_20px_#EDC850]';
      case 1024: return 'bg-[#EDC53F] text-white text-xl shadow-[0_0_25px_#EDC53F]';
      case 2048: return 'bg-[#EDC22E] text-white text-xl shadow-[0_0_30px_#EDC22E]';
      default: return 'bg-[#CDC1B4]/30 text-transparent';
    }
  };

  return (
    <div className="flex flex-col items-center justify-center max-w-sm mx-auto p-4 select-none">
      <div className="flex items-center justify-between w-full mb-3">
        <div>
          <h2 className="text-2xl font-black text-amber-500 tracking-tight">2048</h2>
          <p className="text-xs text-stone-400">Join the numbers</p>
        </div>
        <div className="flex gap-2">
          <div className="bg-stone-800/80 px-3 py-1.5 rounded-lg text-center border border-stone-700/60 min-w-16">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Score</span>
            <span className="text-sm font-bold text-white">{score}</span>
          </div>
          <div className="bg-stone-800/80 px-3 py-1.5 rounded-lg text-center border border-stone-700/60 min-w-16">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Best</span>
            <span className="text-sm font-bold text-amber-400">{bestScore}</span>
          </div>
        </div>
      </div>

      <div className="relative bg-[#BBADA0]/40 p-2.5 rounded-2xl border border-stone-700/60 backdrop-blur-sm shadow-xl w-72 h-72 sm:w-80 sm:h-80">
        <div className="grid grid-cols-4 grid-rows-4 gap-2 w-full h-full">
          {board.map((row, r) =>
            row.map((val, c) => (
              <div
                key={`${r}-${c}`}
                className={`flex items-center justify-center rounded-xl font-bold transition-all duration-100 ${
                  val > 512 ? 'text-lg sm:text-xl' : 'text-xl sm:text-2xl'
                } ${getTileColor(val)}`}
              >
                {val > 0 ? val : ''}
              </div>
            ))
          )}
        </div>

        {gameOver && (
          <div className="absolute inset-0 bg-stone-900/85 backdrop-blur-sm rounded-2xl flex flex-col items-center justify-center p-4 text-center z-10 animate-fade-in">
            <h3 className="text-2xl font-bold text-red-400 mb-1">Game Over!</h3>
            <p className="text-xs text-stone-300 mb-4">Final Score: {score}</p>
            <button
              onClick={resetGame}
              className="bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold px-5 py-2 rounded-xl text-sm transition-transform active:scale-95 shadow-lg"
            >
              Try Again
            </button>
          </div>
        )}

        {hasWon && (
          <div className="absolute top-2 right-2 bg-amber-400 text-stone-950 text-[10px] font-bold px-2 py-0.5 rounded-full shadow">
            🎉 2048 REACHED!
          </div>
        )}
      </div>

      {/* Touch D-Pad for Mobile Responsiveness */}
      <div className="mt-4 flex flex-col items-center gap-1.5 w-full">
        <div className="text-[11px] text-stone-400 mb-1 sm:hidden">Use D-Pad or swipe</div>
        <button
          onClick={() => move('up')}
          className="w-12 h-10 bg-stone-800 hover:bg-stone-700 active:bg-amber-500 active:text-stone-950 rounded-lg text-white font-bold flex items-center justify-center border border-stone-700 text-sm shadow"
          aria-label="Up"
        >
          ▲
        </button>
        <div className="flex gap-4">
          <button
            onClick={() => move('left')}
            className="w-12 h-10 bg-stone-800 hover:bg-stone-700 active:bg-amber-500 active:text-stone-950 rounded-lg text-white font-bold flex items-center justify-center border border-stone-700 text-sm shadow"
            aria-label="Left"
          >
            ◀
          </button>
          <button
            onClick={() => move('down')}
            className="w-12 h-10 bg-stone-800 hover:bg-stone-700 active:bg-amber-500 active:text-stone-950 rounded-lg text-white font-bold flex items-center justify-center border border-stone-700 text-sm shadow"
            aria-label="Down"
          >
            ▼
          </button>
          <button
            onClick={() => move('right')}
            className="w-12 h-10 bg-stone-800 hover:bg-stone-700 active:bg-amber-500 active:text-stone-950 rounded-lg text-white font-bold flex items-center justify-center border border-stone-700 text-sm shadow"
            aria-label="Right"
          >
            ▶
          </button>
        </div>
      </div>

      <div className="flex gap-3 mt-3">
        <button
          onClick={resetGame}
          className="text-xs px-3 py-1.5 rounded-lg bg-stone-800/80 hover:bg-stone-700 text-stone-300 border border-stone-700 transition-colors"
        >
          New Game
        </button>
      </div>
    </div>
  );
};
