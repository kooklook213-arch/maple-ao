import { ArrowLeft, Bookmark, ChevronDown, Trophy } from 'lucide-react';
import { useState } from 'react';
import { GAME_CATALOG } from '@/data/nocturne-games';
import { GameModeId } from '@/types/nocturne';
import { Game2048 } from './Game2048';
import { GameBlooketQuiz } from './GameBlooketQuiz';
import { GameCookieClicker } from './GameCookieClicker';
import { GameDriveMad } from './GameDriveMad';
import { GameFlappy } from './GameFlappy';
import { GameGeometryDash } from './GameGeometryDash';
import { GameMinesweeper } from './GameMinesweeper';
import { GameSlope } from './GameSlope';
import { GameSnake } from './GameSnake';
import { GameSpaceDefender } from './GameSpaceDefender';
import { GameTetris } from './GameTetris';

interface Props {
  activeGameId: GameModeId;
  onSelectGame: (id: GameModeId) => void;
  onScoreSubmit: (gameId: string, score: number) => void;
  onClose: () => void;
}

export function GameArena({ activeGameId, onSelectGame, onScoreSubmit, onClose }: Props) {
  const [catalogOpen, setCatalogOpen] = useState(false);
  const game = GAME_CATALOG.find((item) => item.id === activeGameId) || GAME_CATALOG[0];
  const reportScore = (score: number) => onScoreSubmit(activeGameId, score);

  return (
    <section className="game-stage" aria-label={`${game.title} game`}>
      <header className="game-stage-header">
        <div className="game-stage-title">
          <button className="icon-button" onClick={onClose} aria-label="Back to game library">
            <ArrowLeft size={18} />
          </button>
          <span className="game-glyph" aria-hidden="true">{game.icon}</span>
          <div>
            <div className="game-title-line">
              <h2>{game.title}</h2>
              <span>{game.category}</span>
            </div>
            <p>{game.description}</p>
          </div>
        </div>
        <div className="game-stage-actions">
          <button className="quiet-button" onClick={() => localStorage.setItem('favorite-game', activeGameId)}>
            <Bookmark size={15} /> Save
          </button>
          <button className="quiet-button" onClick={() => setCatalogOpen((open) => !open)} aria-expanded={catalogOpen}>
            Switch game <ChevronDown size={15} />
          </button>
        </div>
      </header>

      {catalogOpen && (
        <div className="game-switcher">
          {GAME_CATALOG.map((item) => (
            <button
              key={item.id}
              className={item.id === activeGameId ? 'is-current' : ''}
              onClick={() => {
                onSelectGame(item.id);
                setCatalogOpen(false);
              }}
            >
              <span>{item.icon}</span>
              <span>{item.title.replace(' (GN-Math)', '')}</span>
            </button>
          ))}
        </div>
      )}

      <div className="game-canvas-wrap">
        {activeGameId === 'drive-mad' && <GameDriveMad onScoreSubmit={reportScore} />}
        {activeGameId === 'slope' && <GameSlope onScoreSubmit={reportScore} />}
        {activeGameId === 'geometry-dash' && <GameGeometryDash onScoreSubmit={reportScore} />}
        {activeGameId === 'cookie-clicker' && <GameCookieClicker onScoreSubmit={reportScore} />}
        {activeGameId === 'tetris' && <GameTetris onScoreSubmit={reportScore} />}
        {activeGameId === '2048' && <Game2048 onScoreSubmit={reportScore} />}
        {activeGameId === 'snake' && <GameSnake onScoreSubmit={reportScore} />}
        {activeGameId === 'space' && <GameSpaceDefender onScoreSubmit={reportScore} />}
        {activeGameId === 'blooket' && <GameBlooketQuiz onScoreSubmit={reportScore} />}
        {activeGameId === 'mines' && <GameMinesweeper onScoreSubmit={reportScore} />}
        {activeGameId === 'flappy' && <GameFlappy onScoreSubmit={reportScore} />}
        {(activeGameId === 'racer' || activeGameId === 'breakout') && <GameSpaceDefender onScoreSubmit={reportScore} />}
      </div>

      <footer className="game-stage-footer">
        <Trophy size={14} /> Scores are saved locally in this browser.
      </footer>
    </section>
  );
}
