"use client"

import { FormEvent, useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { supabase } from "@/lib/supabase/client"

export function LoginForm() {
  const [showOptions, setShowOptions] = useState(false)
  const [mode, setMode] = useState<"sign-in" | "sign-up">("sign-in")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [message, setMessage] = useState("")
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  useEffect(() => {
    if (window.location.hash === "#signup") {
      setMode("sign-up")
      setShowOptions(true)
    }

    function handleAuthMessage(event: MessageEvent) {
      if (event.origin !== window.location.origin || event.data?.type !== "elbert-auth-complete") return
      setLoading(false)
      router.replace("/workspace")
      router.refresh()
    }

    window.addEventListener("message", handleAuthMessage)
    return () => window.removeEventListener("message", handleAuthMessage)
  }, [router])

  async function handleOAuth(provider: "google" | "apple") {
    setLoading(true)
    setMessage("")
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider,
      options: {
        redirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${window.location.origin}/auth/callback`,
        skipBrowserRedirect: true,
        queryParams: { access_type: "offline", prompt: "select_account" },
      },
    })
    if (error) {
      setMessage(error.message)
      setLoading(false)
      return
    }

    if (data?.url) {
      // The preview runs in a cross-origin iframe, so top-level navigation is blocked.
      // Open OAuth in a new tab where the provider can complete its redirect safely.
      const authWindow = window.open(data.url, "elbert-google-auth", "popup,width=520,height=720,left=200,top=80")
      if (!authWindow) {
        setMessage("Your browser blocked the sign-in window. Allow pop-ups and try again.")
        setLoading(false)
      }
    } else {
      setMessage("Unable to start Google sign-in. Please try again.")
      setLoading(false)
    }
  }

  async function handleEmail(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setLoading(true)
    setMessage("")
    const result = mode === "sign-in"
      ? await supabase.auth.signInWithPassword({ email, password })
      : await supabase.auth.signUp({ email, password })

    if (result.error) {
      setMessage(result.error.message)
    } else if (mode === "sign-in") {
      router.push("/workspace")
      router.refresh()
    } else {
      setMessage("Check your email to confirm your account.")
    }
    setLoading(false)
  }

  return (
    <div className="flex min-h-dvh w-full items-center justify-center bg-white">
      <div className="w-full max-w-sm space-y-6 px-4">
        <div className="text-center">
          <h1 className="text-lg font-medium tracking-tight">Welcome Back!</h1>
          <p className="text-xs text-muted-foreground">Enter your credentials to access your account</p>
        </div>

        <div className="space-y-4">
          <Button type="button" onClick={() => handleOAuth("google")} disabled={loading} className="h-11 w-full rounded-none border-0 bg-neutral-900 text-neutral-50 shadow-none transition-colors duration-200 ease hover:bg-neutral-800">
            <svg aria-hidden="true" className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
            </svg>
            Continue with Google
          </Button>

          <div className="relative flex items-center justify-center">
            <span className="text-xs text-muted-foreground">or</span>
          </div>

          <Button type="button" onClick={() => setShowOptions((visible) => !visible)} className="h-11 w-full rounded-none bg-muted text-muted-foreground shadow-none transition-colors duration-200 ease hover:bg-muted/80">
            {showOptions ? "Hide email options" : "Continue with email"}
          </Button>

          {showOptions && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <Button type="button" variant="outline" onClick={() => handleOAuth("apple")} disabled={loading} className="h-10 rounded-none">Apple</Button>
                <Button type="button" variant="outline" onClick={() => { setMode("sign-up"); setMessage("") }} className="h-10 rounded-none">Create account</Button>
              </div>
              <form className="space-y-3" onSubmit={handleEmail}>
                <label className="sr-only" htmlFor="email">Email address</label>
                <input id="email" name="email" type="email" required value={email} onChange={(event) => setEmail(event.target.value)} placeholder="Email address" className="h-11 w-full border border-border bg-white px-3 text-sm outline-none ring-offset-2 focus-visible:ring-2 focus-visible:ring-ring" />
                <label className="sr-only" htmlFor="password">Password</label>
                <input id="password" name="password" type="password" required minLength={6} value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Password" className="h-11 w-full border border-border bg-white px-3 text-sm outline-none ring-offset-2 focus-visible:ring-2 focus-visible:ring-ring" />
                <Button type="submit" disabled={loading} className="h-11 w-full rounded-none">{loading ? "Please wait…" : mode === "sign-up" ? "Sign up with email" : "Sign in with email"}</Button>
              </form>
              {message && <p role="status" className="text-center text-xs text-muted-foreground">{message}</p>}
            </div>
          )}

          <Button
            type="button"
            variant="outline"
            onClick={() => router.push("/workspace")}
            className="h-11 w-full rounded-none border-dashed bg-white text-muted-foreground shadow-none transition-colors duration-200 ease hover:bg-muted/60 hover:text-neutral-900"
          >
            Continue as guest
          </Button>

          <p className="text-center text-xs text-muted-foreground">
            {mode === "sign-up" ? "Already have an account?" : "Don't have an account?"}{" "}
            <button type="button" onClick={() => { setMode(mode === "sign-up" ? "sign-in" : "sign-up"); setShowOptions(true); setMessage("") }} className="underline transition-colors duration-200 ease hover:text-neutral-900">{mode === "sign-up" ? "Sign in" : "Sign up"}</button>
          </p>
        </div>
      </div>
    </div>
  )
}
