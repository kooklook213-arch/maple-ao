import React, { useState, useEffect, useRef, useCallback } from 'react';
import { playSound } from '../../utils/sound';

interface Props {
  onScoreSubmit?: (score: number) => void;
  onExit?: () => void;
}

interface Pipe {
  x: number;
  topHeight: number;
  bottomHeight: number;
  passed: boolean;
}

export const GameFlappy: React.FC<Props> = ({ onScoreSubmit }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [score, setScore] = useState<number>(0);
  const [bestScore, setBestScore] = useState<number>(() => {
    return parseInt(localStorage.getItem('highscore-flappy') || '0', 10);
  });
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [gameStarted, setGameStarted] = useState<boolean>(false);

  const birdRef = useRef({ y: 180, vy: 0, gravity: 0.38, jump: -6.8, radius: 12 });
  const pipesRef = useRef<Pipe[]>([]);
  const frameIdRef = useRef<number>(0);

  const flap = useCallback(() => {
    if (gameOver) {
      resetGame();
      return;
    }
    if (!gameStarted) {
      setGameStarted(true);
    }
    birdRef.current.vy = birdRef.current.jump;
    playSound('jump');
  }, [gameOver, gameStarted]);

  const resetGame = () => {
    birdRef.current = { y: 180, vy: 0, gravity: 0.38, jump: -6.8, radius: 12 };
    pipesRef.current = [];
    setScore(0);
    setGameOver(false);
    setGameStarted(false);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['Space', 'ArrowUp', 'KeyW'].includes(e.code)) {
        e.preventDefault();
        flap();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [flap]);

  useEffect(() => {
    let spawnTimer = 0;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const loop = () => {
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Clear Canvas
      ctx.fillStyle = '#1e1b4b'; // dark night sky
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Stars
      ctx.fillStyle = '#ffffff';
      for (let i = 0; i < 15; i++) {
        const sx = (i * 27) % canvas.width;
        const sy = (i * 41) % (canvas.height - 80);
        ctx.fillRect(sx, sy, 1, 1);
      }

      // Ground
      ctx.fillStyle = '#111827';
      ctx.fillRect(0, canvas.height - 35, canvas.width, 35);
      ctx.fillStyle = '#10b981';
      ctx.fillRect(0, canvas.height - 35, canvas.width, 4);

      if (gameStarted && !gameOver) {
        // Update Bird
        const bird = birdRef.current;
        bird.vy += bird.gravity;
        bird.y += bird.vy;

        // Ground / Ceiling collision
        if (bird.y + bird.radius >= canvas.height - 35 || bird.y - bird.radius <= 0) {
          setGameOver(true);
          playSound('hit');
          playSound('gameover');
          if (onScoreSubmit) onScoreSubmit(score);
        }

        // Spawn Pipes
        spawnTimer++;
        if (spawnTimer % 95 === 0) {
          const gap = 90;
          const minHeight = 40;
          const maxHeight = canvas.height - 35 - gap - minHeight;
          const topH = Math.floor(Math.random() * (maxHeight - minHeight)) + minHeight;
          const bottomH = canvas.height - 35 - gap - topH;

          pipesRef.current.push({
            x: canvas.width + 20,
            topHeight: topH,
            bottomHeight: bottomH,
            passed: false,
          });
        }

        // Move Pipes & Check Collisions
        for (let i = pipesRef.current.length - 1; i >= 0; i--) {
          const p = pipesRef.current[i];
          p.x -= 2.2;

          const pipeW = 44;
          // Check collision
          const bx = 70;
          const by = bird.y;
          const r = bird.radius;

          const inPipeX = bx + r > p.x && bx - r < p.x + pipeW;
          const hitTop = by - r < p.topHeight;
          const hitBottom = by + r > canvas.height - 35 - p.bottomHeight;

          if (inPipeX && (hitTop || hitBottom)) {
            setGameOver(true);
            playSound('hit');
            playSound('gameover');
            if (onScoreSubmit) onScoreSubmit(score);
          }

          // Score check
          if (!p.passed && p.x + pipeW < bx) {
            p.passed = true;
            playSound('score');
            setScore(s => {
              const ns = s + 1;
              if (ns > bestScore) {
                setBestScore(ns);
                localStorage.setItem('highscore-flappy', ns.toString());
              }
              return ns;
            });
          }

          if (p.x + pipeW < -20) {
            pipesRef.current.splice(i, 1);
          }
        }
      }

      // Draw Pipes
      pipesRef.current.forEach(p => {
        const pipeW = 44;
        ctx.fillStyle = '#059669';
        ctx.shadowBlur = 8;
        ctx.shadowColor = '#10b981';

        // Top pipe
        ctx.fillRect(p.x, 0, pipeW, p.topHeight);
        ctx.fillRect(p.x - 3, p.topHeight - 12, pipeW + 6, 12);

        // Bottom pipe
        const bottomY = canvas.height - 35 - p.bottomHeight;
        ctx.fillRect(p.x, bottomY, pipeW, p.bottomHeight);
        ctx.fillRect(p.x - 3, bottomY, pipeW + 6, 12);
        ctx.shadowBlur = 0;
      });

      // Draw Bird (Blooket chick!)
      const bird = birdRef.current;
      const bx = 70;
      const by = bird.y;

      ctx.save();
      ctx.translate(bx, by);
      const angle = Math.min(Math.PI / 4, Math.max(-Math.PI / 4, bird.vy * 0.08));
      ctx.rotate(angle);

      // Body
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#f59e0b';
      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.arc(0, 0, bird.radius, 0, Math.PI * 2);
      ctx.fill();

      // Wing
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.ellipse(-4, 2, 7, 4, -0.2, 0, Math.PI * 2);
      ctx.fill();

      // Eye
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(5, -4, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#000000';
      ctx.beginPath();
      ctx.arc(6, -4, 2, 0, Math.PI * 2);
      ctx.fill();

      // Beak
      ctx.fillStyle = '#ea580c';
      ctx.beginPath();
      ctx.moveTo(9, -1);
      ctx.lineTo(16, 2);
      ctx.lineTo(9, 5);
      ctx.closePath();
      ctx.fill();

      ctx.restore();

      frameIdRef.current = requestAnimationFrame(loop);
    };

    frameIdRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frameIdRef.current);
  }, [gameStarted, gameOver, score, bestScore, onScoreSubmit]);

  return (
    <div className="flex flex-col items-center justify-center max-w-sm mx-auto p-4 select-none">
      <div className="flex items-center justify-between w-full mb-3">
        <div>
          <h2 className="text-2xl font-black text-amber-400 tracking-tight flex items-center gap-1.5">
            <span>🐥</span> Flappy Blook
          </h2>
          <p className="text-xs text-stone-400">Tap / Spacebar to fly</p>
        </div>
        <div className="flex gap-2">
          <div className="bg-stone-800/80 px-2.5 py-1.5 rounded-lg text-center border border-stone-700/60 min-w-14">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Score</span>
            <span className="text-sm font-bold text-white">{score}</span>
          </div>
          <div className="bg-stone-800/80 px-2.5 py-1.5 rounded-lg text-center border border-stone-700/60 min-w-14">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Best</span>
            <span className="text-sm font-bold text-amber-400">{bestScore}</span>
          </div>
        </div>
      </div>

      <div
        onClick={flap}
        className="relative rounded-2xl overflow-hidden border border-amber-500/30 cursor-pointer shadow-xl"
      >
        <canvas ref={canvasRef} width={320} height={380} className="w-72 h-84 sm:w-80 sm:h-96 block" />

        {!gameStarted && !gameOver && (
          <div className="absolute inset-0 bg-stone-950/40 backdrop-blur-[1px] flex flex-col items-center justify-center p-4 text-center">
            <span className="text-4xl animate-bounce mb-2">🐥</span>
            <h3 className="text-xl font-bold text-amber-300 mb-1">Tap to Fly</h3>
            <p className="text-xs text-stone-300">Dodge green pipes to score</p>
          </div>
        )}

        {gameOver && (
          <div className="absolute inset-0 bg-stone-950/80 backdrop-blur-sm flex flex-col items-center justify-center p-4 text-center z-10 animate-fade-in">
            <h3 className="text-2xl font-bold text-red-400 mb-1">Game Over!</h3>
            <p className="text-xs text-stone-300 mb-4">Pipes Passed: {score}</p>
            <button
              onClick={e => {
                e.stopPropagation();
                resetGame();
              }}
              className="bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold px-5 py-2 rounded-xl text-sm transition-transform active:scale-95 shadow-lg"
            >
              Play Again
            </button>
          </div>
        )}
      </div>

      <div className="mt-4 w-full">
        <button
          onClick={flap}
          className="w-full py-3 bg-amber-500 hover:bg-amber-400 active:scale-98 text-stone-950 font-extrabold rounded-xl text-base shadow-lg transition-transform"
        >
          FLAP! 🚀
        </button>
      </div>
    </div>
  );
};
