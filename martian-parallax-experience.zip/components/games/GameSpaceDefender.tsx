import React, { useState, useEffect, useRef, useCallback } from 'react';
import { playSound } from '../../utils/sound';

interface Props {
  onScoreSubmit?: (score: number) => void;
  onExit?: () => void;
}

interface Bullet {
  x: number;
  y: number;
  vy: number;
}

interface Enemy {
  x: number;
  y: number;
  size: number;
  hp: number;
  speed: number;
  color: string;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  alpha: number;
  color: string;
}

export const GameSpaceDefender: React.FC<Props> = ({ onScoreSubmit }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [score, setScore] = useState<number>(0);
  const [bestScore, setBestScore] = useState<number>(() => {
    return parseInt(localStorage.getItem('highscore-space') || '0', 10);
  });
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [lives, setLives] = useState<number>(3);

  const playerRef = useRef({ x: 160, y: 340, width: 28, height: 28, speed: 6 });
  const keysRef = useRef<{ [key: string]: boolean }>({});
  const bulletsRef = useRef<Bullet[]>([]);
  const enemiesRef = useRef<Enemy[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const lastShotRef = useRef<number>(0);
  const frameIdRef = useRef<number>(0);

  const resetGame = useCallback(() => {
    playerRef.current = { x: 160, y: 340, width: 28, height: 28, speed: 6 };
    bulletsRef.current = [];
    enemiesRef.current = [];
    particlesRef.current = [];
    setScore(0);
    setLives(3);
    setGameOver(false);
  }, []);

  const shoot = useCallback(() => {
    const now = Date.now();
    if (now - lastShotRef.current > 160) {
      lastShotRef.current = now;
      bulletsRef.current.push({
        x: playerRef.current.x,
        y: playerRef.current.y - 14,
        vy: -9
      });
      playSound('click');
    }
  }, []);

  const spawnParticles = (x: number, y: number, color: string, count = 8) => {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const spd = Math.random() * 3 + 1;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * spd,
        vy: Math.sin(angle) * spd,
        alpha: 1,
        color
      });
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current[e.code] = true;
      if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Space'].includes(e.code)) {
        e.preventDefault();
      }
      if (e.code === 'Space') {
        shoot();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.code] = false;
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [shoot]);

  useEffect(() => {
    if (gameOver) return;

    let enemySpawnCounter = 0;

    const gameLoop = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const player = playerRef.current;

      // Handle continuous keys
      if (keysRef.current['ArrowLeft'] || keysRef.current['KeyA']) player.x = Math.max(16, player.x - player.speed);
      if (keysRef.current['ArrowRight'] || keysRef.current['KeyD']) player.x = Math.min(canvas.width - 16, player.x + player.speed);
      if (keysRef.current['ArrowUp'] || keysRef.current['KeyW']) player.y = Math.max(30, player.y - player.speed);
      if (keysRef.current['ArrowDown'] || keysRef.current['KeyS']) player.y = Math.min(canvas.height - 20, player.y + player.speed);
      if (keysRef.current['Space']) shoot();

      // Clear Canvas
      ctx.fillStyle = '#060714';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Starfield background
      ctx.fillStyle = '#ffffff';
      for (let s = 0; s < 25; s++) {
        const sx = (s * 37 + (Date.now() * 0.05) % canvas.width) % canvas.width;
        const sy = (s * 59 + (Date.now() * 0.15) % canvas.height) % canvas.height;
        ctx.fillRect(sx, sy, 1.2, 1.2);
      }

      // Spawn enemies
      enemySpawnCounter++;
      if (enemySpawnCounter % 40 === 0) {
        const types = [
          { size: 16, hp: 1, speed: 2.2, color: '#ef4444' },
          { size: 22, hp: 2, speed: 1.5, color: '#f59e0b' },
          { size: 26, hp: 3, speed: 1.1, color: '#ec4899' },
        ];
        const t = types[Math.floor(Math.random() * types.length)];
        enemiesRef.current.push({
          x: Math.random() * (canvas.width - 40) + 20,
          y: -20,
          size: t.size,
          hp: t.hp,
          speed: t.speed,
          color: t.color
        });
      }

      // Update & Draw Bullets
      bulletsRef.current.forEach((b, idx) => {
        b.y += b.vy;
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#60a5fa';
        ctx.fillStyle = '#93c5fd';
        ctx.fillRect(b.x - 2, b.y - 6, 4, 12);
        ctx.shadowBlur = 0;

        if (b.y < -10) {
          bulletsRef.current.splice(idx, 1);
        }
      });

      // Update & Draw Enemies
      for (let eIdx = enemiesRef.current.length - 1; eIdx >= 0; eIdx--) {
        const en = enemiesRef.current[eIdx];
        en.y += en.speed;

        // Collision with bullet
        for (let bIdx = bulletsRef.current.length - 1; bIdx >= 0; bIdx--) {
          const b = bulletsRef.current[bIdx];
          const dist = Math.hypot(b.x - en.x, b.y - en.y);
          if (dist < en.size) {
            bulletsRef.current.splice(bIdx, 1);
            en.hp -= 1;
            spawnParticles(en.x, en.y, '#93c5fd', 4);
            playSound('hit');

            if (en.hp <= 0) {
              spawnParticles(en.x, en.y, en.color, 12);
              enemiesRef.current.splice(eIdx, 1);
              setScore(prev => {
                const ns = prev + 50;
                if (ns > bestScore) {
                  setBestScore(ns);
                  localStorage.setItem('highscore-space', ns.toString());
                }
                return ns;
              });
              break;
            }
          }
        }

        // Collision with player
        const pDist = Math.hypot(player.x - en.x, player.y - en.y);
        if (pDist < en.size + 12) {
          spawnParticles(en.x, en.y, '#ef4444', 16);
          enemiesRef.current.splice(eIdx, 1);
          playSound('hit');
          setLives(l => {
            const nextL = l - 1;
            if (nextL <= 0) {
              setGameOver(true);
              playSound('gameover');
              if (onScoreSubmit) onScoreSubmit(score);
            }
            return nextL;
          });
        }

        if (en.y > canvas.height + 30) {
          enemiesRef.current.splice(eIdx, 1);
        }

        // Draw Enemy
        ctx.shadowBlur = 12;
        ctx.shadowColor = en.color;
        ctx.fillStyle = en.color;
        ctx.beginPath();
        ctx.moveTo(en.x, en.y + en.size);
        ctx.lineTo(en.x - en.size, en.y - en.size);
        ctx.lineTo(en.x + en.size, en.y - en.size);
        ctx.closePath();
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      // Update & Draw Particles
      for (let pIdx = particlesRef.current.length - 1; pIdx >= 0; pIdx--) {
        const pt = particlesRef.current[pIdx];
        pt.x += pt.vx;
        pt.y += pt.vy;
        pt.alpha -= 0.03;
        if (pt.alpha <= 0) {
          particlesRef.current.splice(pIdx, 1);
        } else {
          ctx.fillStyle = pt.color;
          ctx.globalAlpha = pt.alpha;
          ctx.fillRect(pt.x, pt.y, 2.5, 2.5);
          ctx.globalAlpha = 1.0;
        }
      }

      // Draw Player Ship
      ctx.shadowBlur = 14;
      ctx.shadowColor = '#38bdf8';
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.moveTo(player.x, player.y - 14);
      ctx.lineTo(player.x - 14, player.y + 14);
      ctx.lineTo(player.x, player.y + 7);
      ctx.lineTo(player.x + 14, player.y + 14);
      ctx.closePath();
      ctx.fill();

      // Engine Flame
      ctx.fillStyle = '#f97316';
      ctx.beginPath();
      ctx.moveTo(player.x - 5, player.y + 10);
      ctx.lineTo(player.x, player.y + 18 + Math.random() * 6);
      ctx.lineTo(player.x + 5, player.y + 10);
      ctx.closePath();
      ctx.fill();
      ctx.shadowBlur = 0;

      frameIdRef.current = requestAnimationFrame(gameLoop);
    };

    frameIdRef.current = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(frameIdRef.current);
  }, [gameOver, score, bestScore, shoot, onScoreSubmit]);

  return (
    <div className="flex flex-col items-center justify-center max-w-sm mx-auto p-4 select-none">
      <div className="flex items-center justify-between w-full mb-3">
        <div>
          <h2 className="text-2xl font-black text-sky-400 tracking-tight flex items-center gap-1.5">
            <span>🚀</span> Space Defender
          </h2>
          <div className="flex items-center gap-1.5 text-xs text-stone-400">
            <span>Shields:</span>
            {Array.from({ length: 3 }).map((_, i) => (
              <span key={i} className={`text-sm ${i < lives ? 'text-red-500' : 'text-stone-700'}`}>
                ♥
              </span>
            ))}
          </div>
        </div>
        <div className="flex gap-2">
          <div className="bg-stone-800/80 px-3 py-1.5 rounded-lg text-center border border-stone-700/60 min-w-16">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Score</span>
            <span className="text-sm font-bold text-white">{score}</span>
          </div>
          <div className="bg-stone-800/80 px-3 py-1.5 rounded-lg text-center border border-stone-700/60 min-w-16">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Best</span>
            <span className="text-sm font-bold text-sky-400">{bestScore}</span>
          </div>
        </div>
      </div>

      <div className="relative rounded-2xl overflow-hidden border border-sky-500/30 shadow-[0_0_25px_rgba(56,189,248,0.2)]">
        <canvas ref={canvasRef} width={320} height={380} className="w-72 h-84 sm:w-80 sm:h-96 block" />

        {gameOver && (
          <div className="absolute inset-0 bg-stone-950/85 backdrop-blur-sm flex flex-col items-center justify-center p-4 text-center z-10 animate-fade-in">
            <h3 className="text-2xl font-bold text-red-400 mb-1">Fleet Destroyed!</h3>
            <p className="text-xs text-stone-300 mb-4">Final Battle Score: {score}</p>
            <button
              onClick={resetGame}
              className="bg-sky-500 hover:bg-sky-600 text-stone-950 font-bold px-5 py-2 rounded-xl text-sm transition-transform active:scale-95 shadow-lg"
            >
              Relaunch Mission
            </button>
          </div>
        )}
      </div>

      {/* Mobile Controls */}
      <div className="mt-3 flex items-center justify-between w-full px-2">
        <div className="flex gap-2">
          <button
            onTouchStart={() => { keysRef.current['ArrowLeft'] = true; }}
            onTouchEnd={() => { keysRef.current['ArrowLeft'] = false; }}
            onMouseDown={() => { keysRef.current['ArrowLeft'] = true; }}
            onMouseUp={() => { keysRef.current['ArrowLeft'] = false; }}
            className="w-14 h-12 bg-stone-800 active:bg-sky-600 rounded-xl text-white font-bold flex items-center justify-center border border-stone-700 text-lg shadow"
            aria-label="Move Left"
          >
            ◀
          </button>
          <button
            onTouchStart={() => { keysRef.current['ArrowRight'] = true; }}
            onTouchEnd={() => { keysRef.current['ArrowRight'] = false; }}
            onMouseDown={() => { keysRef.current['ArrowRight'] = true; }}
            onMouseUp={() => { keysRef.current['ArrowRight'] = false; }}
            className="w-14 h-12 bg-stone-800 active:bg-sky-600 rounded-xl text-white font-bold flex items-center justify-center border border-stone-700 text-lg shadow"
            aria-label="Move Right"
          >
            ▶
          </button>
        </div>

        <button
          onClick={shoot}
          className="w-20 h-12 bg-red-600 hover:bg-red-500 active:scale-95 rounded-xl text-white font-bold flex items-center justify-center text-sm shadow-[0_0_15px_rgba(239,68,68,0.4)]"
        >
          FIRE 🔥
        </button>
      </div>

      <div className="flex gap-3 mt-3">
        <button
          onClick={resetGame}
          className="text-xs px-3 py-1.5 rounded-lg bg-stone-800/80 hover:bg-stone-700 text-stone-300 border border-stone-700 transition-colors"
        >
          Restart Mission
        </button>
      </div>
    </div>
  );
};
