import React, { useState, useEffect, useRef, useCallback } from 'react';
import { playSound } from '../../utils/sound';

interface Props {
  onScoreSubmit?: (score: number) => void;
  onExit?: () => void;
}

interface Obstacle {
  z: number; // Distance ahead
  lane: number; // -1: left, 0: center, 1: right
  width: number;
}

export const GameSlope: React.FC<Props> = ({ onScoreSubmit }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [score, setScore] = useState<number>(0);
  const [bestScore, setBestScore] = useState<number>(() => {
    return parseInt(localStorage.getItem('highscore-slope') || '0', 10);
  });
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(1);

  // Ball State
  const ballRef = useRef({
    x: 0, // -1 to 1 (track normalized)
    vx: 0,
    radius: 12,
    rollingAngle: 0
  });

  const keysRef = useRef<{ [key: string]: boolean }>({});
  const obstaclesRef = useRef<Obstacle[]>([]);
  const animFrameRef = useRef<number>(0);
  const distanceRef = useRef<number>(0);

  const resetGame = useCallback(() => {
    ballRef.current = { x: 0, vx: 0, radius: 12, rollingAngle: 0 };
    obstaclesRef.current = [];
    distanceRef.current = 0;
    setScore(0);
    setSpeed(1);
    setGameOver(false);
  }, []);

  // Controls
  useEffect(() => {
    const onDown = (e: KeyboardEvent) => {
      keysRef.current[e.code] = true;
      if (['ArrowLeft', 'ArrowRight', 'KeyA', 'KeyD'].includes(e.code)) {
        e.preventDefault();
      }
    };
    const onUp = (e: KeyboardEvent) => {
      keysRef.current[e.code] = false;
    };
    window.addEventListener('keydown', onDown);
    window.addEventListener('keyup', onUp);
    return () => {
      window.removeEventListener('keydown', onDown);
      window.removeEventListener('keyup', onUp);
    };
  }, []);

  // Main 3D Slope Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let obstacleTimer = 0;

    const loop = () => {
      if (!gameOver) {
        const ball = ballRef.current;

        // Steer left/right
        const isLeft = keysRef.current['ArrowLeft'] || keysRef.current['KeyA'];
        const isRight = keysRef.current['ArrowRight'] || keysRef.current['KeyD'];

        if (isLeft) ball.vx -= 0.0035;
        if (isRight) ball.vx += 0.0035;

        ball.vx *= 0.92;
        ball.x += ball.vx;

        // Fall off track check
        if (Math.abs(ball.x) > 1.35) {
          setGameOver(true);
          playSound('hit');
          playSound('gameover');
          if (onScoreSubmit) onScoreSubmit(Math.floor(distanceRef.current));
        }

        // Distance & speed progression
        distanceRef.current += 1.2 * speed;
        setScore(Math.floor(distanceRef.current));
        if (distanceRef.current > bestScore) {
          setBestScore(Math.floor(distanceRef.current));
          localStorage.setItem('highscore-slope', Math.floor(distanceRef.current).toString());
        }

        setSpeed(s => Math.min(2.5, s + 0.0003));
        ball.rollingAngle += 0.2 * speed;

        // Spawn red obstacles
        obstacleTimer++;
        if (obstacleTimer % Math.max(30, Math.floor(65 / speed)) === 0) {
          const lanes = [-0.65, 0, 0.65];
          const l = lanes[Math.floor(Math.random() * lanes.length)];
          obstaclesRef.current.push({
            z: 800,
            lane: l,
            width: 0.45
          });
        }

        // Update obstacles & collision
        for (let i = obstaclesRef.current.length - 1; i >= 0; i--) {
          const ob = obstaclesRef.current[i];
          ob.z -= 11 * speed;

          // Collision with ball (when z is near camera: 60 to 120)
          if (ob.z < 110 && ob.z > 50) {
            if (Math.abs(ball.x - ob.lane) < ob.width / 1.5) {
              setGameOver(true);
              playSound('hit');
              playSound('gameover');
              if (onScoreSubmit) onScoreSubmit(Math.floor(distanceRef.current));
              break;
            }
          }

          if (ob.z < 10) {
            obstaclesRef.current.splice(i, 1);
          }
        }
      }

      // Render 3D Perspective Tunnel & Slope
      ctx.fillStyle = '#05060d';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const fov = 260;
      const horizonY = canvas.height * 0.35;
      const centerX = canvas.width / 2;

      // Draw Grid Lines receding to horizon
      ctx.strokeStyle = '#1e1c3b';
      ctx.lineWidth = 1;
      const trackHalfW = 140;

      // Outer track boundaries
      for (let z = 50; z < 800; z += 50) {
        const pz = z - ((distanceRef.current * 10) % 50);
        const scale = fov / pz;
        const y = horizonY + 80 * scale;
        const w = trackHalfW * scale;

        ctx.strokeStyle = pz < 200 ? '#433d7a' : '#221e42';
        ctx.beginPath();
        ctx.moveTo(centerX - w, y);
        ctx.lineTo(centerX + w, y);
        ctx.stroke();
      }

      // Longitudinal lines
      [-1, -0.5, 0, 0.5, 1].forEach(t => {
        ctx.strokeStyle = t === -1 || t === 1 ? '#06b6d4' : '#2d2859';
        ctx.lineWidth = t === -1 || t === 1 ? 2.5 : 1;
        ctx.beginPath();
        const y1 = horizonY + 80 * (fov / 800);
        const x1 = centerX + t * trackHalfW * (fov / 800);
        const y2 = canvas.height;
        const x2 = centerX + t * trackHalfW * (fov / 50);
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      });

      // Draw Red Obstacles
      obstaclesRef.current.forEach(ob => {
        if (ob.z > 30) {
          const scale = fov / ob.z;
          const sx = centerX + ob.lane * trackHalfW * scale;
          const sy = horizonY + 80 * scale;
          const sw = ob.width * trackHalfW * scale;
          const sh = 28 * scale;

          ctx.fillStyle = '#ef4444';
          ctx.shadowBlur = 12;
          ctx.shadowColor = '#f87171';
          ctx.beginPath();
          ctx.roundRect(sx - sw / 2, sy - sh, sw, sh, 4);
          ctx.fill();

          // Obstacle top warning strip
          ctx.fillStyle = '#fca5a5';
          ctx.fillRect(sx - sw / 2 + 2, sy - sh + 2, sw - 4, sh * 0.3);
          ctx.shadowBlur = 0;
        }
      });

      // Draw Green Neon Rolling Ball
      const ball = ballRef.current;
      const ballScale = fov / 70;
      const bx = centerX + ball.x * trackHalfW * ballScale;
      const by = horizonY + 80 * ballScale - ball.radius;

      // Ball shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
      ctx.beginPath();
      ctx.ellipse(bx, by + ball.radius, ball.radius * 1.1, ball.radius * 0.4, 0, 0, Math.PI * 2);
      ctx.fill();

      // Ball body
      ctx.shadowBlur = 16;
      ctx.shadowColor = '#10b981';
      ctx.fillStyle = '#34d399';
      ctx.beginPath();
      ctx.arc(bx, by, ball.radius, 0, Math.PI * 2);
      ctx.fill();

      // Ball highlights & roll lines
      ctx.shadowBlur = 0;
      ctx.strokeStyle = '#059669';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(bx, by, ball.radius * 0.7, ball.rollingAngle, ball.rollingAngle + Math.PI);
      ctx.stroke();

      animFrameRef.current = requestAnimationFrame(loop);
    };

    animFrameRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [gameOver, speed, bestScore, onScoreSubmit]);

  return (
    <div className="flex flex-col items-center justify-center max-w-sm mx-auto p-3 select-none">
      <div className="flex items-center justify-between w-full mb-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-emerald-400 tracking-tight flex items-center gap-1.5">
            <span>⚡</span> Slope 3D (GN-Math)
          </h2>
          <p className="text-xs text-stone-400">Dodge red walls on the infinite slope</p>
        </div>

        <div className="flex gap-2">
          <div className="bg-stone-900 border border-stone-700 px-3 py-1.5 rounded-xl text-center min-w-16">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Score</span>
            <span className="text-sm font-black text-white">{score}</span>
          </div>
          <div className="bg-stone-900 border border-stone-700 px-3 py-1.5 rounded-xl text-center min-w-16">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Best</span>
            <span className="text-sm font-black text-emerald-400">{bestScore}</span>
          </div>
        </div>
      </div>

      <div className="relative rounded-2xl overflow-hidden border border-emerald-500/40 shadow-[0_0_25px_rgba(16,185,129,0.2)] bg-black">
        <canvas ref={canvasRef} width={340} height={320} className="w-72 h-68 sm:w-80 sm:h-76 block" />

        {gameOver && (
          <div className="absolute inset-0 bg-stone-950/85 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center z-10 animate-fade-in">
            <span className="text-4xl mb-1">💥</span>
            <h3 className="text-xl font-bold text-red-400 mb-1">Slope Wipeout!</h3>
            <p className="text-xs text-stone-300 mb-4">Distance Survived: {score} meters</p>
            <button
              onClick={resetGame}
              className="bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-bold px-6 py-2 rounded-xl text-xs shadow-lg transition-transform active:scale-95"
            >
              Play Again
            </button>
          </div>
        )}
      </div>

      {/* Touch Steering for Mobile */}
      <div className="mt-3 flex items-center justify-center gap-6 w-full">
        <button
          onTouchStart={() => { keysRef.current['ArrowLeft'] = true; }}
          onTouchEnd={() => { keysRef.current['ArrowLeft'] = false; }}
          onMouseDown={() => { keysRef.current['ArrowLeft'] = true; }}
          onMouseUp={() => { keysRef.current['ArrowLeft'] = false; }}
          className="w-24 h-12 bg-stone-800 active:bg-emerald-600 rounded-xl text-white font-bold flex items-center justify-center border border-stone-700 shadow text-lg"
          aria-label="Steer Left"
        >
          ◀ STEER
        </button>
        <button
          onTouchStart={() => { keysRef.current['ArrowRight'] = true; }}
          onTouchEnd={() => { keysRef.current['ArrowRight'] = false; }}
          onMouseDown={() => { keysRef.current['ArrowRight'] = true; }}
          onMouseUp={() => { keysRef.current['ArrowRight'] = false; }}
          className="w-24 h-12 bg-stone-800 active:bg-emerald-600 rounded-xl text-white font-bold flex items-center justify-center border border-stone-700 shadow text-lg"
          aria-label="Steer Right"
        >
          STEER ▶
        </button>
      </div>
    </div>
  );
};
