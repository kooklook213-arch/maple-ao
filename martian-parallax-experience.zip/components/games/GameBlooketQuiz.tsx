import React, { useState, useEffect, useCallback } from 'react';
import { playSound } from '../../utils/sound';

interface Props {
  onScoreSubmit?: (score: number) => void;
  onExit?: () => void;
}

interface Question {
  q: string;
  options: string[];
  correct: number;
  subject: string;
}

const QUESTIONS: Question[] = [
  {
    q: 'Which protocol is used for secure encrypted data transmission over the web?',
    options: ['HTTP', 'HTTPS', 'FTP', 'SMTP'],
    correct: 1,
    subject: 'Computer Science'
  },
  {
    q: 'What is the largest planet in our Solar System?',
    options: ['Saturn', 'Jupiter', 'Neptune', 'Earth'],
    correct: 1,
    subject: 'Astronomy'
  },
  {
    q: 'In JavaScript, which method converts a JSON string into an object?',
    options: ['JSON.stringify()', 'JSON.parse()', 'JSON.toObject()', 'JSON.build()'],
    correct: 1,
    subject: 'Coding'
  },
  {
    q: 'What element has the chemical symbol "Au"?',
    options: ['Silver', 'Argon', 'Gold', 'Aluminum'],
    correct: 2,
    subject: 'Chemistry'
  },
  {
    q: 'Which data structure follows the First-In, First-Out (FIFO) principle?',
    options: ['Stack', 'Queue', 'Tree', 'Graph'],
    correct: 1,
    subject: 'Data Structures'
  },
  {
    q: 'Who was the primary author of the United States Declaration of Independence?',
    options: ['George Washington', 'Benjamin Franklin', 'Thomas Jefferson', 'Alexander Hamilton'],
    correct: 2,
    subject: 'History'
  },
  {
    q: 'What is the value of 2^8?',
    options: ['128', '256', '512', '1024'],
    correct: 1,
    subject: 'Math'
  },
  {
    q: 'Which CSS property is used to create flexible layout grids without floats?',
    options: ['display: flex', 'float: left', 'align-items: center', 'margin: auto'],
    correct: 0,
    subject: 'Web Dev'
  }
];

export const GameBlooketQuiz: React.FC<Props> = ({ onScoreSubmit }) => {
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [gold, setGold] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [isCorrect, setIsCorrect] = useState<boolean>(false);
  const [chestPhase, setChestPhase] = useState<boolean>(false);
  const [openedChest, setOpenedChest] = useState<number | null>(null);
  const [chestRewards, setChestRewards] = useState<number[]>([100, 250, 500]);
  const [timeLeft, setTimeLeft] = useState<number>(15);
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [blookAvatar, setBlookAvatar] = useState<string>('🦊');

  const blooks = ['🦊', '🦉', '🐸', '🚀', '🦄', '🐼', '🤖'];

  const resetGame = useCallback(() => {
    setCurrentIdx(0);
    setGold(0);
    setStreak(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setChestPhase(false);
    setOpenedChest(null);
    setTimeLeft(15);
    setGameOver(false);
  }, []);

  // Timer
  useEffect(() => {
    if (gameOver || chestPhase || isAnswered) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleTimeout();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [gameOver, chestPhase, isAnswered, currentIdx]);

  const handleTimeout = () => {
    setIsAnswered(true);
    setIsCorrect(false);
    setStreak(0);
    playSound('hit');
    setTimeout(() => {
      nextQuestion();
    }, 1500);
  };

  const handleAnswer = (optionIdx: number) => {
    if (isAnswered) return;
    setSelectedOption(optionIdx);
    setIsAnswered(true);

    const question = QUESTIONS[currentIdx];
    const correct = optionIdx === question.correct;
    setIsCorrect(correct);

    if (correct) {
      playSound('task');
      setStreak(s => s + 1);
      // Trigger chest phase
      const baseRewards = [
        Math.floor(Math.random() * 150) + 100,
        Math.floor(Math.random() * 300) + 200,
        Math.floor(Math.random() * 500) + 350
      ].sort(() => Math.random() - 0.5);

      setChestRewards(baseRewards);
      setTimeout(() => {
        setChestPhase(true);
      }, 700);
    } else {
      playSound('hit');
      setStreak(0);
      setTimeout(() => {
        nextQuestion();
      }, 1500);
    }
  };

  const openChest = (chestIdx: number) => {
    if (openedChest !== null) return;
    setOpenedChest(chestIdx);
    const reward = chestRewards[chestIdx];
    playSound('score');
    setGold(g => g + reward + streak * 25);

    setTimeout(() => {
      setChestPhase(false);
      setOpenedChest(null);
      nextQuestion();
    }, 1200);
  };

  const nextQuestion = () => {
    setSelectedOption(null);
    setIsAnswered(false);
    setTimeLeft(15);

    if (currentIdx + 1 < QUESTIONS.length) {
      setCurrentIdx(i => i + 1);
    } else {
      setGameOver(true);
      playSound('success');
      if (onScoreSubmit) onScoreSubmit(gold);
    }
  };

  const curQ = QUESTIONS[currentIdx];

  return (
    <div className="flex flex-col items-center justify-center max-w-md mx-auto p-4 select-none">
      {/* Top Banner */}
      <div className="flex items-center justify-between w-full mb-3">
        <div className="flex items-center gap-2">
          <div className="relative group cursor-pointer" title="Switch your Blook">
            <span className="text-3xl p-1 bg-amber-500/20 rounded-xl border border-amber-500/40 inline-block transition-transform hover:scale-110">
              {blookAvatar}
            </span>
            <div className="absolute top-full left-0 mt-1 bg-stone-900 border border-stone-700 rounded-lg p-1.5 hidden group-hover:flex gap-1 z-30 shadow-xl">
              {blooks.map(b => (
                <button
                  key={b}
                  onClick={() => setBlookAvatar(b)}
                  className="p-1 hover:bg-stone-800 rounded text-lg"
                >
                  {b}
                </button>
              ))}
            </div>
          </div>
          <div>
            <h2 className="text-xl font-black text-amber-400 tracking-tight flex items-center gap-1">
              Blooket Rush
            </h2>
            <div className="flex items-center gap-2 text-xs">
              <span className="text-stone-400">{curQ?.subject || 'Trivia'}</span>
              {streak > 1 && (
                <span className="text-amber-400 font-bold bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
                  🔥 {streak}x Streak
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="bg-amber-500/10 border border-amber-500/30 px-3 py-1.5 rounded-xl flex items-center gap-1.5">
            <span className="text-base">🪙</span>
            <span className="font-extrabold text-amber-300 text-sm">{gold}</span>
          </div>
          <div className={`px-2.5 py-1 rounded-xl text-xs font-bold border ${timeLeft <= 4 ? 'bg-red-500/20 border-red-500 text-red-300 animate-pulse' : 'bg-stone-800 border-stone-700 text-stone-300'}`}>
            ⏱️ {timeLeft}s
          </div>
        </div>
      </div>

      {/* Main Play Area */}
      <div className="w-full bg-stone-900/90 border border-stone-700/80 rounded-2xl p-5 shadow-2xl backdrop-blur-md relative min-h-[320px] flex flex-col justify-between">
        {!chestPhase && !gameOver && curQ && (
          <>
            <div>
              <div className="flex justify-between items-center text-xs text-stone-400 mb-2">
                <span>Question {currentIdx + 1} of {QUESTIONS.length}</span>
                <div className="w-28 bg-stone-800 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-amber-500 h-full transition-all duration-300"
                    style={{ width: `${((currentIdx + 1) / QUESTIONS.length) * 100}%` }}
                  />
                </div>
              </div>
              <h3 className="text-lg font-bold text-white mb-6 leading-snug">
                {curQ.q}
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 w-full">
              {curQ.options.map((opt, idx) => {
                let btnStyle = 'bg-stone-800 hover:bg-stone-750 text-stone-200 border-stone-700';
                if (isAnswered) {
                  if (idx === curQ.correct) {
                    btnStyle = 'bg-emerald-600 border-emerald-400 text-white shadow-[0_0_15px_rgba(16,185,129,0.4)]';
                  } else if (idx === selectedOption) {
                    btnStyle = 'bg-red-600 border-red-400 text-white';
                  } else {
                    btnStyle = 'bg-stone-850 text-stone-500 border-stone-800 opacity-50';
                  }
                }

                const colors = ['border-l-4 border-l-red-500', 'border-l-4 border-l-blue-500', 'border-l-4 border-l-amber-500', 'border-l-4 border-l-emerald-500'];

                return (
                  <button
                    key={idx}
                    disabled={isAnswered}
                    onClick={() => handleAnswer(idx)}
                    className={`p-3.5 rounded-xl text-sm font-semibold text-left transition-all duration-150 border active:scale-98 flex items-center justify-between ${btnStyle} ${!isAnswered ? colors[idx % 4] : ''}`}
                  >
                    <span>{opt}</span>
                    {isAnswered && idx === curQ.correct && <span>✓</span>}
                  </button>
                );
              })}
            </div>
          </>
        )}

        {/* Chest Phase: Mystery Boxes */}
        {chestPhase && !gameOver && (
          <div className="flex flex-col items-center justify-center py-6 text-center animate-fade-in">
            <h4 className="text-xl font-extrabold text-amber-400 mb-1">Correct! Choose a Mystery Chest 🎁</h4>
            <p className="text-xs text-stone-300 mb-6">Pick one chest to claim your gold bonus!</p>
            <div className="grid grid-cols-3 gap-3 w-full max-w-xs">
              {[0, 1, 2].map(cIdx => (
                <button
                  key={cIdx}
                  disabled={openedChest !== null}
                  onClick={() => openChest(cIdx)}
                  className={`flex flex-col items-center justify-center p-4 rounded-2xl border transition-all duration-200 ${
                    openedChest === cIdx
                      ? 'bg-amber-500/30 border-amber-400 scale-105 shadow-[0_0_20px_rgba(245,158,11,0.5)]'
                      : 'bg-stone-800/80 border-stone-700 hover:border-amber-500/60 hover:bg-stone-750 active:scale-95'
                  }`}
                >
                  <span className="text-4xl mb-2 animate-bounce">
                    {openedChest === cIdx ? '🪙' : '📦'}
                  </span>
                  <span className="text-xs font-bold text-amber-300">
                    {openedChest === cIdx ? `+${chestRewards[cIdx]} Gold` : `Chest #${cIdx + 1}`}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Game Over Screen */}
        {gameOver && (
          <div className="flex flex-col items-center justify-center py-6 text-center animate-fade-in">
            <span className="text-5xl mb-2">🏆</span>
            <h3 className="text-2xl font-black text-amber-400 mb-1">Quiz Completed!</h3>
            <p className="text-stone-300 text-sm mb-4">Total Gold Collected:</p>
            <div className="bg-amber-500/20 border border-amber-500/40 rounded-2xl px-6 py-3 mb-6 flex items-center gap-2">
              <span className="text-2xl">🪙</span>
              <span className="text-3xl font-black text-amber-300">{gold}</span>
            </div>
            <button
              onClick={resetGame}
              className="bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold px-6 py-2.5 rounded-xl text-sm transition-transform active:scale-95 shadow-lg"
            >
              Play Another Round
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
