import React, { useState, useEffect, useRef, useCallback } from 'react';
import { playSound } from '../../utils/sound';

interface Props {
  onScoreSubmit?: (score: number) => void;
  onExit?: () => void;
}

const COLS = 10;
const ROWS = 20;

// Tetromino definitions
const TETROMINOES = {
  I: { shape: [[0, 0, 0, 0], [1, 1, 1, 1], [0, 0, 0, 0], [0, 0, 0, 0]], color: '#06b6d4' },
  O: { shape: [[1, 1], [1, 1]], color: '#fbbf24' },
  T: { shape: [[0, 1, 0], [1, 1, 1], [0, 0, 0]], color: '#a855f7' },
  S: { shape: [[0, 1, 1], [1, 1, 0], [0, 0, 0]], color: '#22c55e' },
  Z: { shape: [[1, 1, 0], [0, 1, 1], [0, 0, 0]], color: '#ef4444' },
  J: { shape: [[1, 0, 0], [1, 1, 1], [0, 0, 0]], color: '#3b82f6' },
  L: { shape: [[0, 0, 1], [1, 1, 1], [0, 0, 0]], color: '#f97316' },
};

type PieceKey = keyof typeof TETROMINOES;

export const GameTetris: React.FC<Props> = ({ onScoreSubmit }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [score, setScore] = useState<number>(0);
  const [lines, setLines] = useState<number>(0);
  const [bestScore, setBestScore] = useState<number>(() => {
    return parseInt(localStorage.getItem('highscore-tetris') || '0', 10);
  });
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);

  // Board State
  const boardRef = useRef<string[][]>(
    Array.from({ length: ROWS }, () => Array(COLS).fill(''))
  );

  const currentPieceRef = useRef<{
    shape: number[][];
    color: string;
    x: number;
    y: number;
  }>({
    shape: TETROMINOES.T.shape,
    color: TETROMINOES.T.color,
    x: 3,
    y: 0
  });

  const getRandomPiece = () => {
    const keys = Object.keys(TETROMINOES) as PieceKey[];
    const k = keys[Math.floor(Math.random() * keys.length)];
    const p = TETROMINOES[k];
    return {
      shape: p.shape,
      color: p.color,
      x: Math.floor((COLS - p.shape[0].length) / 2),
      y: 0
    };
  };

  const checkCollision = (shape: number[][], px: number, py: number, board: string[][]) => {
    for (let r = 0; r < shape.length; r++) {
      for (let c = 0; c < shape[r].length; c++) {
        if (shape[r][c] !== 0) {
          const bx = px + c;
          const by = py + r;
          if (bx < 0 || bx >= COLS || by >= ROWS) return true;
          if (by >= 0 && board[by][bx] !== '') return true;
        }
      }
    }
    return false;
  };

  const rotatePiece = (shape: number[][]) => {
    const N = shape.length;
    const rotated: number[][] = Array.from({ length: N }, () => Array(N).fill(0));
    for (let r = 0; r < N; r++) {
      for (let c = 0; c < N; c++) {
        rotated[c][N - 1 - r] = shape[r][c];
      }
    }
    return rotated;
  };

  const lockPiece = useCallback(() => {
    const piece = currentPieceRef.current;
    const board = boardRef.current;

    for (let r = 0; r < piece.shape.length; r++) {
      for (let c = 0; c < piece.shape[r].length; c++) {
        if (piece.shape[r][c] !== 0) {
          const by = piece.y + r;
          const bx = piece.x + c;
          if (by < 0) {
            setGameOver(true);
            playSound('hit');
            playSound('gameover');
            return;
          }
          board[by][bx] = piece.color;
        }
      }
    }

    // Line clears
    let cleared = 0;
    for (let r = ROWS - 1; r >= 0; r--) {
      if (board[r].every(cell => cell !== '')) {
        board.splice(r, 1);
        board.unshift(Array(COLS).fill(''));
        cleared++;
        r++;
      }
    }

    if (cleared > 0) {
      playSound('success');
      const pts = cleared === 4 ? 1200 : cleared * 200;
      setScore(s => {
        const next = s + pts;
        if (next > bestScore) {
          setBestScore(next);
          localStorage.setItem('highscore-tetris', next.toString());
        }
        if (onScoreSubmit) onScoreSubmit(next);
        return next;
      });
      setLines(l => l + cleared);
    } else {
      playSound('click');
    }

    // Spawn new piece
    const nextPiece = getRandomPiece();
    if (checkCollision(nextPiece.shape, nextPiece.x, nextPiece.y, board)) {
      setGameOver(true);
      playSound('hit');
      playSound('gameover');
    } else {
      currentPieceRef.current = nextPiece;
    }
  }, [bestScore, onScoreSubmit]);

  const moveLeft = useCallback(() => {
    const piece = currentPieceRef.current;
    if (!checkCollision(piece.shape, piece.x - 1, piece.y, boardRef.current)) {
      piece.x -= 1;
      playSound('click');
    }
  }, []);

  const moveRight = useCallback(() => {
    const piece = currentPieceRef.current;
    if (!checkCollision(piece.shape, piece.x + 1, piece.y, boardRef.current)) {
      piece.x += 1;
      playSound('click');
    }
  }, []);

  const rotate = useCallback(() => {
    const piece = currentPieceRef.current;
    const rotated = rotatePiece(piece.shape);
    if (!checkCollision(rotated, piece.x, piece.y, boardRef.current)) {
      piece.shape = rotated;
      playSound('click');
    }
  }, []);

  const drop = useCallback(() => {
    const piece = currentPieceRef.current;
    if (!checkCollision(piece.shape, piece.x, piece.y + 1, boardRef.current)) {
      piece.y += 1;
    } else {
      lockPiece();
    }
  }, [lockPiece]);

  const hardDrop = useCallback(() => {
    const piece = currentPieceRef.current;
    while (!checkCollision(piece.shape, piece.x, piece.y + 1, boardRef.current)) {
      piece.y += 1;
    }
    lockPiece();
  }, [lockPiece]);

  // Controls
  useEffect(() => {
    const onDown = (e: KeyboardEvent) => {
      if (gameOver || isPaused) return;
      if (e.code === 'ArrowLeft' || e.code === 'KeyA') {
        e.preventDefault();
        moveLeft();
      } else if (e.code === 'ArrowRight' || e.code === 'KeyD') {
        e.preventDefault();
        moveRight();
      } else if (e.code === 'ArrowUp' || e.code === 'KeyW') {
        e.preventDefault();
        rotate();
      } else if (e.code === 'ArrowDown' || e.code === 'KeyS') {
        e.preventDefault();
        drop();
      } else if (e.code === 'Space') {
        e.preventDefault();
        hardDrop();
      }
    };
    window.addEventListener('keydown', onDown);
    return () => window.removeEventListener('keydown', onDown);
  }, [gameOver, isPaused, moveLeft, moveRight, rotate, drop, hardDrop]);

  // Game Loop Ticker
  useEffect(() => {
    if (gameOver || isPaused) return;
    const interval = setInterval(() => {
      drop();
    }, 600);
    return () => clearInterval(interval);
  }, [gameOver, isPaused, drop]);

  // Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const blockSize = canvas.width / COLS;

    // Clear Board
    ctx.fillStyle = '#060714';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Subtle grid
    ctx.strokeStyle = '#121326';
    ctx.lineWidth = 0.5;
    for (let r = 0; r <= ROWS; r++) {
      ctx.beginPath();
      ctx.moveTo(0, r * blockSize);
      ctx.lineTo(canvas.width, r * blockSize);
      ctx.stroke();
    }
    for (let c = 0; c <= COLS; c++) {
      ctx.beginPath();
      ctx.moveTo(c * blockSize, 0);
      ctx.lineTo(c * blockSize, canvas.height);
      ctx.stroke();
    }

    // Draw Locked Blocks
    const board = boardRef.current;
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        if (board[r][c]) {
          ctx.fillStyle = board[r][c];
          ctx.shadowBlur = 8;
          ctx.shadowColor = board[r][c];
          ctx.beginPath();
          ctx.roundRect(c * blockSize + 1, r * blockSize + 1, blockSize - 2, blockSize - 2, 3);
          ctx.fill();
          ctx.shadowBlur = 0;
        }
      }
    }

    // Ghost Piece Projection
    const piece = currentPieceRef.current;
    let ghostY = piece.y;
    while (!checkCollision(piece.shape, piece.x, ghostY + 1, board)) {
      ghostY++;
    }

    for (let r = 0; r < piece.shape.length; r++) {
      for (let c = 0; c < piece.shape[r].length; c++) {
        if (piece.shape[r][c] !== 0) {
          ctx.strokeStyle = piece.color;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.roundRect(
            (piece.x + c) * blockSize + 2,
            (ghostY + r) * blockSize + 2,
            blockSize - 4,
            blockSize - 4,
            2
          );
          ctx.stroke();
        }
      }
    }

    // Draw Current Active Piece
    for (let r = 0; r < piece.shape.length; r++) {
      for (let c = 0; c < piece.shape[r].length; c++) {
        if (piece.shape[r][c] !== 0) {
          ctx.fillStyle = piece.color;
          ctx.shadowBlur = 12;
          ctx.shadowColor = piece.color;
          ctx.beginPath();
          ctx.roundRect(
            (piece.x + c) * blockSize + 1,
            (piece.y + r) * blockSize + 1,
            blockSize - 2,
            blockSize - 2,
            3
          );
          ctx.fill();
          ctx.shadowBlur = 0;
        }
      }
    }
  });

  const resetGame = () => {
    boardRef.current = Array.from({ length: ROWS }, () => Array(COLS).fill(''));
    currentPieceRef.current = getRandomPiece();
    setScore(0);
    setLines(0);
    setGameOver(false);
  };

  return (
    <div className="flex flex-col items-center justify-center max-w-sm mx-auto p-3 select-none">
      <div className="flex items-center justify-between w-full mb-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-cyan-400 tracking-tight flex items-center gap-1.5">
            <span>🧩</span> Tetris (GN-Math)
          </h2>
          <p className="text-xs text-stone-400">Lines: {lines} · Clear lines to score</p>
        </div>

        <div className="flex gap-2">
          <div className="bg-stone-900 border border-stone-700 px-3 py-1.5 rounded-xl text-center min-w-16">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Score</span>
            <span className="text-sm font-black text-white">{score}</span>
          </div>
          <div className="bg-stone-900 border border-stone-700 px-3 py-1.5 rounded-xl text-center min-w-16">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Best</span>
            <span className="text-sm font-black text-cyan-400">{bestScore}</span>
          </div>
        </div>
      </div>

      <div className="relative rounded-2xl overflow-hidden border border-cyan-500/40 shadow-[0_0_25px_rgba(6,182,212,0.2)] bg-black">
        <canvas ref={canvasRef} width={220} height={440} className="w-52 h-[410px] block" />

        {gameOver && (
          <div className="absolute inset-0 bg-stone-950/85 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center z-10 animate-fade-in">
            <span className="text-4xl mb-1">💥</span>
            <h3 className="text-xl font-bold text-red-400 mb-1">Game Over!</h3>
            <p className="text-xs text-stone-300 mb-4">Lines Cleared: {lines}</p>
            <button
              onClick={resetGame}
              className="bg-cyan-500 hover:bg-cyan-400 text-stone-950 font-bold px-6 py-2 rounded-xl text-xs shadow-lg transition-transform active:scale-95"
            >
              Play Again
            </button>
          </div>
        )}
      </div>

      {/* Touch D-Pad for Mobile */}
      <div className="mt-3 flex flex-col items-center gap-1.5 w-full">
        <div className="flex gap-3">
          <button
            onClick={rotate}
            className="w-14 h-11 bg-stone-800 active:bg-cyan-600 rounded-xl text-white font-bold flex items-center justify-center border border-stone-700 shadow"
            title="Rotate"
          >
            ↻ ROT
          </button>
          <button
            onClick={hardDrop}
            className="w-20 h-11 bg-cyan-600 active:bg-cyan-500 text-stone-950 font-black rounded-xl flex items-center justify-center shadow"
            title="Hard Drop"
          >
            DROP ⚡
          </button>
        </div>

        <div className="flex gap-3">
          <button
            onClick={moveLeft}
            className="w-14 h-11 bg-stone-800 active:bg-cyan-600 rounded-xl text-white font-bold flex items-center justify-center border border-stone-700 shadow text-lg"
          >
            ◀
          </button>
          <button
            onClick={drop}
            className="w-14 h-11 bg-stone-800 active:bg-cyan-600 rounded-xl text-white font-bold flex items-center justify-center border border-stone-700 shadow text-lg"
          >
            ▼
          </button>
          <button
            onClick={moveRight}
            className="w-14 h-11 bg-stone-800 active:bg-cyan-600 rounded-xl text-white font-bold flex items-center justify-center border border-stone-700 shadow text-lg"
          >
            ▶
          </button>
        </div>
      </div>
    </div>
  );
};
