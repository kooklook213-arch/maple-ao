import React, { useState, useEffect, useCallback } from 'react';
import { playSound } from '../../utils/sound';

interface Props {
  onScoreSubmit?: (score: number) => void;
  onExit?: () => void;
}

const ROWS = 9;
const COLS = 9;
const MINES = 10;

interface Cell {
  r: number;
  c: number;
  isMine: boolean;
  isRevealed: boolean;
  isFlagged: boolean;
  count: number;
}

export const GameMinesweeper: React.FC<Props> = ({ onScoreSubmit }) => {
  const [grid, setGrid] = useState<Cell[][]>([]);
  const [flagsLeft, setFlagsLeft] = useState<number>(MINES);
  const [seconds, setSeconds] = useState<number>(0);
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [won, setWon] = useState<boolean>(false);
  const [started, setStarted] = useState<boolean>(false);
  const [flagMode, setFlagMode] = useState<boolean>(false); // mobile toggle

  const initGrid = useCallback(() => {
    const newGrid: Cell[][] = [];
    for (let r = 0; r < ROWS; r++) {
      const row: Cell[] = [];
      for (let c = 0; c < COLS; c++) {
        row.push({
          r,
          c,
          isMine: false,
          isRevealed: false,
          isFlagged: false,
          count: 0,
        });
      }
      newGrid.push(row);
    }

    // Place mines randomly
    let placed = 0;
    while (placed < MINES) {
      const rr = Math.floor(Math.random() * ROWS);
      const cc = Math.floor(Math.random() * COLS);
      if (!newGrid[rr][cc].isMine) {
        newGrid[rr][cc].isMine = true;
        placed++;
      }
    }

    // Calculate neighboring mines
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        if (!newGrid[r][c].isMine) {
          let count = 0;
          for (let dr = -1; dr <= 1; dr++) {
            for (let dc = -1; dc <= 1; dc++) {
              const nr = r + dr;
              const nc = c + dc;
              if (nr >= 0 && nr < ROWS && nc >= 0 && nc < COLS && newGrid[nr][nc].isMine) {
                count++;
              }
            }
          }
          newGrid[r][c].count = count;
        }
      }
    }

    setGrid(newGrid);
    setFlagsLeft(MINES);
    setSeconds(0);
    setGameOver(false);
    setWon(false);
    setStarted(false);
  }, []);

  useEffect(() => {
    initGrid();
  }, [initGrid]);

  // Timer
  useEffect(() => {
    if (!started || gameOver || won) return;
    const interval = setInterval(() => {
      setSeconds(s => s + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [started, gameOver, won]);

  const revealCell = (r: number, c: number) => {
    if (gameOver || won) return;
    if (!started) setStarted(true);

    const cell = grid[r][c];
    if (cell.isRevealed || cell.isFlagged) return;

    if (flagMode) {
      toggleFlag(r, c);
      return;
    }

    if (cell.isMine) {
      playSound('hit');
      playSound('gameover');
      setGameOver(true);
      // Reveal all mines
      const revealed = grid.map(row =>
        row.map(cl => (cl.isMine ? { ...cl, isRevealed: true } : cl))
      );
      setGrid(revealed);
      return;
    }

    playSound('click');
    const newGrid = grid.map(row => row.map(cl => ({ ...cl })));
    floodFill(newGrid, r, c);
    setGrid(newGrid);

    // Check Win Condition
    let unrevealedSafe = 0;
    for (let i = 0; i < ROWS; i++) {
      for (let j = 0; j < COLS; j++) {
        if (!newGrid[i][j].isMine && !newGrid[i][j].isRevealed) {
          unrevealedSafe++;
        }
      }
    }

    if (unrevealedSafe === 0) {
      setWon(true);
      playSound('success');
      const score = Math.max(10, 1000 - seconds * 10);
      if (onScoreSubmit) onScoreSubmit(score);
    }
  };

  const floodFill = (g: Cell[][], r: number, c: number) => {
    if (r < 0 || r >= ROWS || c < 0 || c >= COLS) return;
    const cell = g[r][c];
    if (cell.isRevealed || cell.isFlagged || cell.isMine) return;

    cell.isRevealed = true;
    if (cell.count === 0) {
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr !== 0 || dc !== 0) {
            floodFill(g, r + dr, c + dc);
          }
        }
      }
    }
  };

  const toggleFlag = (r: number, c: number, e?: React.MouseEvent) => {
    if (e) e.preventDefault();
    if (gameOver || won) return;
    if (!started) setStarted(true);

    const cell = grid[r][c];
    if (cell.isRevealed) return;

    const newGrid = grid.map(row => row.map(cl => ({ ...cl })));
    const target = newGrid[r][c];
    if (target.isFlagged) {
      target.isFlagged = false;
      setFlagsLeft(f => f + 1);
    } else {
      if (flagsLeft > 0) {
        target.isFlagged = true;
        setFlagsLeft(f => f - 1);
      }
    }
    setGrid(newGrid);
  };

  const getNumberColor = (num: number) => {
    const colors = [
      '',
      'text-blue-400',
      'text-emerald-400',
      'text-red-400',
      'text-purple-400',
      'text-amber-400',
      'text-cyan-400',
      'text-rose-400',
      'text-stone-300'
    ];
    return colors[num] || 'text-white';
  };

  return (
    <div className="flex flex-col items-center justify-center max-w-sm mx-auto p-4 select-none">
      <div className="flex items-center justify-between w-full mb-3">
        <div>
          <h2 className="text-2xl font-black text-rose-400 tracking-tight flex items-center gap-1.5">
            <span>💣</span> Minesweeper 99
          </h2>
          <p className="text-xs text-stone-400">Clear without detonating</p>
        </div>
        <div className="flex gap-2">
          <div className="bg-stone-800/80 px-2.5 py-1.5 rounded-lg text-center border border-stone-700/60 min-w-14">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Mines</span>
            <span className="text-sm font-bold text-red-400">{flagsLeft}</span>
          </div>
          <div className="bg-stone-800/80 px-2.5 py-1.5 rounded-lg text-center border border-stone-700/60 min-w-14">
            <span className="text-[10px] uppercase font-bold text-stone-400 block">Time</span>
            <span className="text-sm font-bold text-white">{seconds}s</span>
          </div>
        </div>
      </div>

      <div className="bg-stone-900 border border-stone-700/80 p-3 rounded-2xl shadow-xl flex flex-col items-center">
        {/* Status Smiley Bar */}
        <div className="flex justify-between items-center w-full mb-3 px-1">
          <button
            onClick={() => setFlagMode(m => !m)}
            className={`px-3 py-1 text-xs rounded-lg font-bold border transition-colors flex items-center gap-1 ${
              flagMode
                ? 'bg-rose-500/20 text-rose-300 border-rose-500'
                : 'bg-stone-800 text-stone-300 border-stone-700'
            }`}
          >
            <span>🚩 Flag Mode:</span>
            <span>{flagMode ? 'ON' : 'OFF'}</span>
          </button>
          <button
            onClick={initGrid}
            className="text-2xl hover:scale-110 active:scale-95 transition-transform p-1 bg-stone-800 rounded-xl border border-stone-700"
            title="Restart"
          >
            {gameOver ? '😵' : won ? '😎' : '🙂'}
          </button>
        </div>

        {/* 9x9 Board */}
        <div className="grid grid-cols-9 gap-1 bg-stone-950 p-2 rounded-xl border border-stone-800">
          {grid.map((row, r) =>
            row.map((cell, c) => (
              <button
                key={`${r}-${c}`}
                onClick={() => revealCell(r, c)}
                onContextMenu={e => toggleFlag(r, c, e)}
                className={`w-7 h-7 sm:w-8 sm:h-8 rounded flex items-center justify-center font-bold text-xs transition-all ${
                  cell.isRevealed
                    ? cell.isMine
                      ? 'bg-red-600/80 text-white'
                      : 'bg-stone-800 text-stone-100 shadow-inner'
                    : 'bg-stone-700 hover:bg-stone-650 active:bg-stone-600 border-t border-l border-stone-600'
                }`}
              >
                {cell.isRevealed ? (
                  cell.isMine ? (
                    '💣'
                  ) : cell.count > 0 ? (
                    <span className={getNumberColor(cell.count)}>{cell.count}</span>
                  ) : (
                    ''
                  )
                ) : cell.isFlagged ? (
                  '🚩'
                ) : (
                  ''
                )}
              </button>
            ))
          )}
        </div>

        {won && (
          <div className="mt-3 text-emerald-400 font-bold text-sm text-center animate-bounce">
            🎉 Minefield Cleared in {seconds} seconds!
          </div>
        )}
        {gameOver && (
          <div className="mt-3 text-red-400 font-bold text-sm text-center">
            💥 Boom! Mine detonated.
          </div>
        )}
      </div>

      <div className="flex gap-3 mt-3">
        <button
          onClick={initGrid}
          className="text-xs px-3 py-1.5 rounded-lg bg-stone-800/80 hover:bg-stone-700 text-stone-300 border border-stone-700 transition-colors"
        >
          Reset Board
        </button>
      </div>
    </div>
  );
};
