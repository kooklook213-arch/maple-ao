'use client';

import React, { useState, useMemo, useRef } from 'react';
import rawGames from '@/data/gnmath_games.json';
import { Search, Flame, Gamepad2, Maximize2, Minimize2, ExternalLink, Bookmark, X, Play, Sparkles, Filter, RefreshCw, Trophy } from 'lucide-react';
import { playSound } from '@/utils/nocturne-sound';

interface GNGame {
  id: number;
  name: string;
  cover: string;
  url: string;
  author: string;
  authorLink: string;
}

interface Props {
  onBookmarkGame?: (title: string, url: string, category: 'games', gameId?: string) => void;
}

const GAMES = rawGames as GNGame[];
const FEATURED_IDS = new Set([0, 1, 2, 3, 4, 7, 8, 9, 10, 11, 24, 27, 33, 34, 43, 70, 71, 72, 73, 74, 75, 410, 443]);

export const GNMathPage: React.FC<Props> = ({ onBookmarkGame }) => {
  const games = GAMES;
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedGame, setSelectedGame] = useState<GNGame | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [displayCount, setDisplayCount] = useState(24);
  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  // Filter Categories
  const categories = [
    { id: 'all', label: 'All Games', count: games.length },
    { id: 'featured', label: '⭐ Top Featured', count: 24 },
    { id: 'fnaf', label: '🐻 FNAF Series', count: games.filter(g => g.name.toLowerCase().includes('fnaf') || g.name.toLowerCase().includes('freddy')).length },
    { id: 'retro-bowl', label: '🏈 Retro Bowl', count: games.filter(g => g.name.toLowerCase().includes('retro bowl')).length },
    { id: 'ovo', label: '🏃 OvO Series', count: games.filter(g => g.name.toLowerCase().includes('ovo')).length },
    { id: 'action', label: '⚔️ Action & Battle', count: games.filter(g => /gladihopper|stickman|supreme|battle|combat/i.test(g.name)).length },
    { id: 'runner', label: '🏎️ Speed & Runner', count: games.filter(g => /run|dash|drift|speed|driver|road/i.test(g.name)).length }
  ];

  const filteredGames = useMemo(() => {
    let list = games;

    if (selectedCategory === 'featured') {
      list = list.filter(g => FEATURED_IDS.has(g.id));
    } else if (selectedCategory === 'fnaf') {
      list = list.filter(g => g.name.toLowerCase().includes('fnaf') || g.name.toLowerCase().includes('freddy'));
    } else if (selectedCategory === 'retro-bowl') {
      list = list.filter(g => g.name.toLowerCase().includes('retro bowl'));
    } else if (selectedCategory === 'ovo') {
      list = list.filter(g => g.name.toLowerCase().includes('ovo'));
    } else if (selectedCategory === 'action') {
      list = list.filter(g => /gladihopper|stickman|supreme|battle|combat|attack|bowmaster/i.test(g.name));
    } else if (selectedCategory === 'runner') {
      list = list.filter(g => /run|dash|drift|speed|driver|road|turbo|jump/i.test(g.name));
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(g =>
        g.name.toLowerCase().includes(q) ||
        (g.author && g.author.toLowerCase().includes(q))
      );
    }

    return list;
  }, [games, selectedCategory, searchQuery]);

  const displayedList = filteredGames.slice(0, displayCount);

  const handleOpenGame = (game: GNGame) => {
    playSound('task');
    setSelectedGame(game);
  };

  const handleCloseGame = () => {
    setSelectedGame(null);
    setIsFullscreen(false);
  };

  const handleToggleFullscreen = () => {
    if (!iframeRef.current) return;
    if (!isFullscreen) {
      if (iframeRef.current.requestFullscreen) {
        iframeRef.current.requestFullscreen();
      }
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
      setIsFullscreen(false);
    }
  };

  const handleBookmark = (game: GNGame) => {
    playSound('success');
    if (onBookmarkGame) {
      onBookmarkGame(game.name, `/api/gnmath/game-frame/${game.id}`, 'games', `gn-${game.id}`);
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4 sm:p-8 max-w-7xl mx-auto w-full">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="text-3xl">🎮</span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#26251F] tracking-tight">
              GN-Math Arcade (gn-math.dev)
            </h1>
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#D97757]/15 text-[#D97757] border border-[#D97757]/30">
              840 Real Games
            </span>
          </div>
          <p className="text-sm text-[#8A877C] mt-1">
            The full unblocked game database synced directly from <a href="https://gn-math.dev/" target="_blank" rel="noreferrer" className="text-[#3E6FD9] underline">gn-math.dev</a> with real in-app playability!
          </p>
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => {
              setSearchQuery(e.target.value);
              setDisplayCount(24);
            }}
            placeholder="Search 840+ games (e.g. Retro Bowl, FNAF, OvO)..."
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-[#E5E2D8] bg-white text-xs sm:text-sm text-[#26251F] focus:outline-none focus:border-[#D97757] shadow-xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-3 mb-4">
        {categories.map(c => (
          <button
            key={c.id}
            onClick={() => {
              playSound('click');
              setSelectedCategory(c.id);
              setDisplayCount(24);
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 border ${
              selectedCategory === c.id
                ? 'bg-[#26251F] text-white border-[#26251F] shadow-xs'
                : 'bg-white text-stone-600 border-[#E5E2D8] hover:border-stone-400'
            }`}
          >
            <span>{c.label}</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${selectedCategory === c.id ? 'bg-white/20 text-white' : 'bg-stone-100 text-stone-500'}`}>
              {c.count}
            </span>
          </button>
        ))}
      </div>

      {/* ACTIVE GAME VIEWER MODAL / IN-APP PLAYER */}
      {selectedGame && (
        <div className="mb-8 bg-[#05060d] text-white rounded-2xl border border-[#2b274e] p-4 shadow-2xl animate-fade-in flex flex-col gap-3">
          {/* Top Controls Bar */}
          <div className="flex items-center justify-between pb-3 border-b border-[#1c1a36] flex-wrap gap-2">
            <div className="flex items-center gap-3">
              <img
                src={selectedGame.cover}
                alt={selectedGame.name}
                className="w-10 h-10 rounded-lg object-cover border border-[#3b3666]"
                onError={e => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <div>
                <h3 className="font-extrabold text-base text-white leading-tight flex items-center gap-2">
                  <span>{selectedGame.name}</span>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">
                    GN-Math
                  </span>
                </h3>
                {selectedGame.author && (
                  <p className="text-xs text-stone-400">
                    By{' '}
                    {selectedGame.authorLink ? (
                      <a href={selectedGame.authorLink} target="_blank" rel="noreferrer" className="text-[#9085e9] underline">
                        {selectedGame.author}
                      </a>
                    ) : (
                      selectedGame.author
                    )}
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleBookmark(selectedGame)}
                className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors"
                title="Bookmark Game"
              >
                <Bookmark className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Bookmark</span>
              </button>

              <a
                href={selectedGame.url}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 bg-[#9085e9] hover:bg-[#a399fa] text-[#05060d] text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors"
                title="Open in Full Tab"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">New Tab</span>
              </a>

              <button
                onClick={handleToggleFullscreen}
                className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors"
                title="Toggle Fullscreen"
              >
                <Maximize2 className="w-4 h-4" />
              </button>

              <button
                onClick={handleCloseGame}
                className="p-2 bg-red-500/20 hover:bg-red-500/40 text-red-300 rounded-lg transition-colors"
                title="Close Game"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Game Iframe */}
          <div className="w-full h-[620px] rounded-xl overflow-hidden bg-black relative border border-[#2b274e]">
            <iframe
              ref={iframeRef}
              src={selectedGame.url}
              title={selectedGame.name}
              className="w-full h-full border-0"
              loading="lazy"
              allow="autoplay; fullscreen; gamepad; focus-without-user-activation *"
            />
          </div>
        </div>
      )}

      {/* Games Catalog Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
        {displayedList.map(game => (
          <div
            key={game.id}
            onClick={() => handleOpenGame(game)}
            className="gn-game-card group bg-white rounded-2xl border border-[#E7E4DB] overflow-hidden hover:border-[#D97757] hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between"
          >
            {/* Cover Image */}
            <div className="relative aspect-4/3 w-full bg-[#18162e] overflow-hidden">
              <img
                src={game.cover}
                alt={game.name}
                loading="lazy"
                decoding="async"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                onError={e => {
                  // Fallback colored card with initial
                  const target = e.target as HTMLElement;
                  target.style.display = 'none';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-2.5">
                <span className="px-2.5 py-1 bg-[#D97757] text-white text-[11px] font-bold rounded-lg flex items-center gap-1 shadow">
                  <Play className="w-3 h-3 fill-current" />
                  Play
                </span>
              </div>
            </div>

            {/* Game Info */}
            <div className="p-3 flex flex-col justify-between flex-1">
              <div>
                <h4 className="font-bold text-xs sm:text-sm text-[#26251F] group-hover:text-[#D97757] transition-colors line-clamp-1">
                  {game.name}
                </h4>
                {game.author && (
                  <p className="text-[11px] text-[#8A877C] truncate mt-0.5">
                    {game.author}
                  </p>
                )}
              </div>

              <div className="mt-2 pt-2 border-t border-[#F2F1EA] flex items-center justify-between text-[10px] text-stone-500 font-semibold">
                <span>GN #{game.id}</span>
                <span className="text-[#3E6FD9] group-hover:underline">Play Now →</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Load More Button */}
      {displayCount < filteredGames.length && (
        <div className="mt-8 flex justify-center">
          <button
            onClick={() => setDisplayCount(prev => prev + 60)}
            className="px-6 py-3 bg-[#26251F] hover:bg-black text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition-transform active:scale-98 flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Load More Games (Showing {displayCount} of {filteredGames.length})</span>
          </button>
        </div>
      )}
    </div>
  );
};
